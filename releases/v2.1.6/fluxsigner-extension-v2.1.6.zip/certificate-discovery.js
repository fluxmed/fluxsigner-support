/**
 * FluxSigner - Certificate Discovery Interface
 * Interface para descoberta automática de certificados digitais
 */

class CertificateDiscovery {
    constructor() {
        this.certificates = [];
        this.filteredCertificates = [];
        this.currentView = 'grid';
        this.selectedCertificate = null;
        this.pinAttempts = 3;
        
        this.initializeElements();
        this.setupEventListeners();
        this.loadInitialCertificates();
    }

    /**
     * Inicializa referências dos elementos DOM
     */
    initializeElements() {
        this.elements = {
            // Ações principais
            refreshBtn: document.getElementById('refreshCertificates'),
            uploadBtn: document.getElementById('uploadCertificate'),
            startDiscoveryBtn: document.getElementById('startDiscovery'),
            
            // Filtros
            searchInput: document.getElementById('searchInput'),
            sourceFilter: document.getElementById('sourceFilter'),
            icpOnlyFilter: document.getElementById('icpOnlyFilter'),
            
            // Status da descoberta
            discoveryStatus: document.getElementById('discoveryStatus'),
            progressFill: document.getElementById('progressFill'),
            
            // Resumo dos resultados
            resultsSummary: document.getElementById('resultsSummary'),
            totalFound: document.getElementById('totalFound'),
            validCerts: document.getElementById('validCerts'),
            icpCerts: document.getElementById('icpCerts'),
            discoveryTime: document.getElementById('discoveryTime'),
            providerStatus: document.getElementById('providerStatus'),
            
            // Container de certificados
            certificatesContainer: document.getElementById('certificatesContainer'),
            emptyState: document.getElementById('emptyState'),
            
            // Modal de detalhes
            detailsModal: document.getElementById('detailsModal'),
            modalTitle: document.getElementById('modalTitle'),
            modalBody: document.getElementById('modalBody'),
            modalClose: document.getElementById('modalClose'),
            useCertificate: document.getElementById('useCertificate'),
            testCertificate: document.getElementById('testCertificate'),
            
            // Modal de PIN
            pinModal: document.getElementById('pinModal'),
            tokenPin: document.getElementById('tokenPin'),
            confirmPin: document.getElementById('confirmPin'),
            cancelPin: document.getElementById('cancelPin'),
            pinAttempts: document.getElementById('pinAttempts'),
            attemptsLeft: document.getElementById('attemptsLeft'),
            
            // Modal de teste
            testModal: document.getElementById('testModal'),
            testModalBody: document.getElementById('testModalBody'),
            
            // Modal de upload
            uploadModal: document.getElementById('uploadModal'),
            certificateFile: document.getElementById('certificateFile'),
            certificatePassword: document.getElementById('certificatePassword'),
            certificateAlias: document.getElementById('certificateAlias'),
            uploadCancelBtn: document.getElementById('uploadCancelBtn'),
            uploadConfirmBtn: document.getElementById('uploadConfirmBtn'),
            uploadProgress: document.getElementById('uploadProgress'),
            
            // Notificações
            notificationsContainer: document.getElementById('notificationsContainer')
        };
    }

    /**
     * Configura event listeners
     */
    setupEventListeners() {
        // Ações principais
        this.elements.refreshBtn.addEventListener('click', () => this.discoverCertificates(true));
        this.elements.uploadBtn.addEventListener('click', () => this.openUploadModal());
        
        if (this.elements.startDiscoveryBtn) {
            this.elements.startDiscoveryBtn.addEventListener('click', () => this.discoverCertificates());
        }
        
        // Filtros
        this.elements.searchInput.addEventListener('input', () => this.applyFilters());
        this.elements.sourceFilter.addEventListener('change', () => this.applyFilters());
        this.elements.icpOnlyFilter.addEventListener('change', () => this.applyFilters());
        
        // Visualização
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.changeView(e.target.dataset.view));
        });
        
        // Modal de detalhes
        this.elements.modalClose.addEventListener('click', () => this.closeDetailsModal());
        this.elements.useCertificate.addEventListener('click', () => this.useCertificate());
        this.elements.testCertificate.addEventListener('click', () => this.testCertificate());
        
        // Modal de PIN
        this.elements.confirmPin.addEventListener('click', () => this.confirmPin());
        this.elements.cancelPin.addEventListener('click', () => this.closePinModal());
        this.elements.tokenPin.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.confirmPin();
        });
        
        // Modal de upload
        this.elements.uploadCancelBtn.addEventListener('click', () => this.closeUploadModal());
        this.elements.uploadConfirmBtn.addEventListener('click', () => this.uploadCertificate());
        
        // Fechar modais clicando fora
        window.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                e.target.style.display = 'none';
            }
        });
        
        // Atalhos de teclado
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
            if (e.ctrlKey && e.key === 'f') {
                e.preventDefault();
                this.elements.searchInput.focus();
            }
        });
    }

    /**
     * Carrega certificados automaticamente na inicialização
     */
    async loadInitialCertificates() {
        try {
            // Tentar carregar do cache primeiro
            await this.discoverCertificates();
        } catch (error) {
            console.error('Erro ao carregar certificados:', error);
            
            // Verificar se é erro de host não instalado
            if (error.message === 'HOST_NOT_INSTALLED') {
                this.showHostNotInstalledModal();
            } else {
                this.showError('Erro ao carregar certificados: ' + error.message);
            }
        }
    }

    /**
     * Descobre certificados instalados na máquina
     */
    async discoverCertificates(forceRefresh = false) {
        try {
            this.showDiscoveryStatus('Iniciando busca de certificados...');
            this.updateProgress(10);
            
            // Preparar dados da requisição
            const requestData = {
                forceRefresh: forceRefresh
            };
            
            this.updateProgress(30);
            this.showDiscoveryStatus('Executando descoberta...');
            
            // Enviar requisição para busca unificada (descoberta + upload)
            const response = await this.sendMessage('GET_ALL_CERTIFICATES', requestData);
            
            this.updateProgress(70);
            this.showDiscoveryStatus('Processando resultados...');
            
            const result = JSON.parse(response);
            
            if (!result.success) {
                throw new Error(result.message || 'Erro na descoberta de certificados');
            }
            
            this.certificates = result.certificates || [];
            this.updateProgress(90);
            
            // Atualizar interface
            this.updateResultsSummary(result);
            this.applyFilters();
            this.updateProgress(100);
            
            setTimeout(() => {
                this.hideDiscoveryStatus();
            }, 1000);
            
            this.showSuccess(`✅ Descoberta concluída: ${this.certificates.length} certificados encontrados`);
            this.log(`Descoberta concluída: ${this.certificates.length} certificados encontrados`);
            
        } catch (error) {
            this.hideDiscoveryStatus();
            this.showError(`Erro na descoberta: ${error.message}`);
            this.log(`❌ Erro na descoberta: ${error.message}`);
        }
    }

    /**
     * Mostra status da descoberta
     */
    showDiscoveryStatus(message) {
        this.elements.discoveryStatus.style.display = 'block';
        this.elements.discoveryStatus.querySelector('.status-text').textContent = message;
        this.elements.refreshBtn.disabled = true;
    }

    /**
     * Esconde status da descoberta
     */
    hideDiscoveryStatus() {
        this.elements.discoveryStatus.style.display = 'none';
        this.elements.refreshBtn.disabled = false;
    }

    /**
     * Atualiza barra de progresso
     */
    updateProgress(percentage) {
        this.elements.progressFill.style.width = percentage + '%';
    }

    /**
     * Atualiza resumo dos resultados
     */
    updateResultsSummary(result) {
        const totalFound = result.totalFound || 0;
        const discoveredCount = result.discoveredCount || 0;
        const uploadedCount = result.uploadedCount || 0;
        const icpCerts = this.certificates.filter(cert => cert.icpBrasilCompliant).length;
        const searchTime = result.searchDuration || result.discoveryDuration || 0;
        
        this.elements.totalFound.textContent = totalFound;
        this.elements.validCerts.textContent = `${discoveredCount} descobertos + ${uploadedCount} uploadados`;
        this.elements.icpCerts.textContent = icpCerts;
        this.elements.discoveryTime.textContent = searchTime;
        
        // Atualizar status dos providers (se disponível)
        if (result.providerStatus) {
            this.updateProviderStatus(result.providerStatus);
        }
        
        this.elements.resultsSummary.style.display = 'block';
    }

    /**
     * Atualiza status dos providers
     */
    updateProviderStatus(providers) {
        const html = providers.map(provider => {
            const statusClass = provider.error ? 'error' : 'success';
            const statusIcon = provider.error ? '❌' : '✅';
            const statusText = provider.error ? 
                `Erro: ${provider.error}` : 
                `${provider.certificatesFound} certificados`;
            
            return `
                <div class="provider-item ${statusClass}">
                    <span class="provider-icon">${statusIcon}</span>
                    <span class="provider-name">${provider.name}</span>
                    <span class="provider-status">${statusText}</span>
                </div>
            `;
        }).join('');
        
        this.elements.providerStatus.innerHTML = html;
    }

    /**
     * Aplica filtros aos certificados
     */
    applyFilters() {
        const searchTerm = this.elements.searchInput.value.toLowerCase();
        const sourceFilter = this.elements.sourceFilter.value;
        const icpOnly = this.elements.icpOnlyFilter.checked;
        
        this.filteredCertificates = this.certificates.filter(cert => {
            // Filtro de busca
            if (searchTerm) {
                const searchableText = [
                    cert.friendlyName || '',
                    cert.alias || '',
                    cert.description || '',
                    this.extractCN(cert.certificate?.subject || '')
                ].join(' ').toLowerCase();
                
                if (!searchableText.includes(searchTerm)) {
                    return false;
                }
            }
            
            // Filtro de fonte
            if (sourceFilter && cert.source !== sourceFilter) {
                return false;
            }
            
            // Filtro ICP-Brasil
            if (icpOnly && !cert.icpBrasilCompliant) {
                return false;
            }
            
            return true;
        });
        
        this.renderCertificates();
    }

    /**
     * Renderiza lista de certificados
     */
    renderCertificates() {
        if (this.filteredCertificates.length === 0) {
            this.elements.certificatesContainer.innerHTML = '';
            this.elements.emptyState.style.display = 'block';
            return;
        }
        
        this.elements.emptyState.style.display = 'none';
        
        if (this.currentView === 'grid') {
            this.renderGridView();
        } else {
            this.renderListView();
        }
    }

    /**
     * Renderiza visualização em grade
     */
    renderGridView() {
        const html = this.filteredCertificates.map(cert => this.createCertificateCard(cert)).join('');
        this.elements.certificatesContainer.innerHTML = `<div class="certificates-grid">${html}</div>`;
        this.attachCertificateEventListeners();
    }

    /**
     * Renderiza visualização em lista
     */
    renderListView() {
        const html = this.filteredCertificates.map(cert => this.createCertificateListItem(cert)).join('');
        this.elements.certificatesContainer.innerHTML = `<div class="certificates-list">${html}</div>`;
        this.attachCertificateEventListeners();
    }

    /**
     * Cria card de certificado
     */
    createCertificateCard(cert) {
        const statusClass = this.getCertificateStatusClass(cert);
        const sourceIcon = this.getSourceIcon(cert.source);
        const requiresPinBadge = cert.requiresPin ? '<span class="badge pin-required">🔐 PIN</span>' : '';
        const icpBadge = cert.icpBrasilCompliant ? '<span class="badge icp-brasil">🇧🇷 ICP</span>' : '';
        const sourceBadge = this.getSourceBadge(cert.source);
        
        const validityInfo = cert.certificate ? this.getCertificateValidityInfo(cert.certificate) : null;
        
        return `
            <div class="certificate-card ${statusClass}" data-cert-id="${cert.alias}">
                <div class="card-header">
                    <div class="cert-icon">${sourceIcon}</div>
                    <div class="cert-badges">
                        ${sourceBadge}
                        ${requiresPinBadge}
                        ${icpBadge}
                    </div>
                </div>
                
                <div class="card-body">
                    <h3 class="cert-name">${this.escapeHtml(cert.friendlyName || cert.alias)}</h3>
                    <p class="cert-subject">${this.extractCN(cert.certificate?.subject || '')}</p>
                    <p class="cert-source">${this.getSourceDisplayName(cert.source)}</p>
                    
                    ${validityInfo ? `
                        <div class="cert-validity">
                            <span class="validity-label">Válido até:</span>
                            <span class="validity-date">${validityInfo.notAfter}</span>
                        </div>
                    ` : ''}
                </div>
                
                <div class="card-footer">
                    <button class="btn btn-small btn-secondary cert-details-btn">Ver Detalhes</button>
                    <button class="btn btn-small btn-primary cert-use-btn">Usar</button>
                </div>
            </div>
        `;
    }

    /**
     * Cria item de lista de certificado
     */
    createCertificateListItem(cert) {
        const statusClass = this.getCertificateStatusClass(cert);
        const sourceIcon = this.getSourceIcon(cert.source);
        const statusIcon = this.getStatusIcon(cert);
        
        const validityInfo = cert.certificate ? this.getCertificateValidityInfo(cert.certificate) : null;
        
        return `
            <div class="certificate-list-item ${statusClass}" data-cert-id="${cert.alias}">
                <div class="item-icon">${sourceIcon}</div>
                
                <div class="item-content">
                    <div class="item-main">
                        <h4 class="cert-name">${this.escapeHtml(cert.friendlyName || cert.alias)}</h4>
                        <span class="cert-source">${this.getSourceDisplayName(cert.source)}</span>
                    </div>
                    
                    <div class="item-details">
                        <span class="cert-subject">${this.extractCN(cert.certificate?.subject || '')}</span>
                        ${validityInfo ? `
                            <span class="cert-validity">Válido até ${validityInfo.notAfter}</span>
                        ` : ''}
                    </div>
                </div>
                
                <div class="item-badges">
                    ${cert.requiresPin ? '<span class="badge pin">🔐</span>' : ''}
                    ${cert.icpBrasilCompliant ? '<span class="badge icp">🇧🇷</span>' : ''}
                </div>
                
                <div class="item-status">
                    <span class="status-icon">${statusIcon}</span>
                </div>
                
                <div class="item-actions">
                    <button class="btn btn-small cert-details-btn">Detalhes</button>
                    <button class="btn btn-small btn-primary cert-use-btn">Usar</button>
                </div>
            </div>
        `;
    }

    /**
     * Anexa event listeners aos certificados
     */
    attachCertificateEventListeners() {
        // Botões de detalhes
        document.querySelectorAll('.cert-details-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const certId = e.target.closest('[data-cert-id]').dataset.certId;
                this.showCertificateDetails(certId);
            });
        });
        
        // Botões de usar
        document.querySelectorAll('.cert-use-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const certId = e.target.closest('[data-cert-id]').dataset.certId;
                this.selectCertificateForUse(certId);
            });
        });
        
        // Clique no card/item
        document.querySelectorAll('[data-cert-id]').forEach(item => {
            item.addEventListener('click', (e) => {
                if (!e.target.closest('button')) {
                    const certId = item.dataset.certId;
                    this.showCertificateDetails(certId);
                }
            });
        });
    }

    /**
     * Mostra detalhes do certificado
     */
    showCertificateDetails(certId) {
        const cert = this.certificates.find(c => c.alias === certId);
        if (!cert) return;
        
        this.selectedCertificate = cert;
        
        const modalBody = this.createCertificateDetailsHTML(cert);
        this.elements.modalTitle.textContent = cert.friendlyName || cert.alias;
        this.elements.modalBody.innerHTML = modalBody;
        
        // Configurar botões
        this.elements.useCertificate.innerHTML = cert.requiresPin ? 
            '<span class="btn-icon">🔐</span> Usar (Requer PIN)' : 
            '<span class="btn-icon">✅</span> Usar Certificado';
        
        this.elements.testCertificate.disabled = !cert.certificate;
        
        this.elements.detailsModal.style.display = 'flex';
    }

    /**
     * Cria HTML dos detalhes do certificado
     */
    createCertificateDetailsHTML(cert) {
        const hasValidation = cert.icpValidation;
        const validityInfo = cert.certificate ? this.getCertificateValidityInfo(cert.certificate) : null;
        
        return `
            <div class="cert-details-container">
                <!-- Informações Básicas -->
                <div class="detail-section">
                    <h4>Informações Básicas</h4>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <span class="label">Nome:</span>
                            <span class="value">${this.escapeHtml(cert.friendlyName || cert.alias)}</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Fonte:</span>
                            <span class="value">${this.getSourceDisplayName(cert.source)}</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Local:</span>
                            <span class="value">${this.escapeHtml(cert.storeLocation || 'N/A')}</span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Requer PIN:</span>
                            <span class="value ${cert.requiresPin ? 'requires-pin' : 'no-pin'}">
                                ${cert.requiresPin ? '🔐 Sim' : '✅ Não'}
                            </span>
                        </div>
                        <div class="detail-item">
                            <span class="label">Chave Privada:</span>
                            <span class="value ${cert.hasPrivateKey ? 'no-pin' : 'requires-pin'}">
                                ${cert.hasPrivateKey ? '✅ Disponível' : '❌ Não disponível'}
                            </span>
                        </div>
                    </div>
                </div>
                
                ${cert.certificate && validityInfo ? `
                    <!-- Informações do Certificado -->
                    <div class="detail-section">
                        <h4>Certificado Digital</h4>
                        <div class="detail-grid">
                            <div class="detail-item">
                                <span class="label">Titular:</span>
                                <span class="value">${this.extractCN(validityInfo.subject)}</span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Emissor:</span>
                                <span class="value">${this.extractCN(validityInfo.issuer)}</span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Válido de:</span>
                                <span class="value">${validityInfo.notBefore}</span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Válido até:</span>
                                <span class="value">${validityInfo.notAfter}</span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Número de Série:</span>
                                <span class="value small">${validityInfo.serialNumber}</span>
                            </div>
                        </div>
                    </div>
                ` : ''}
                
                ${hasValidation ? `
                    <!-- Validação ICP-Brasil -->
                    <div class="detail-section">
                        <h4>Validação ICP-Brasil</h4>
                        <div class="validation-status ${cert.icpValidation.valid ? 'valid' : 'invalid'}">
                            <span class="status-icon">${cert.icpValidation.valid ? '✅' : '❌'}</span>
                            <span class="status-text">
                                ${cert.icpValidation.valid ? 'Certificado ICP-Brasil Válido' : 'Não conforme ICP-Brasil'}
                            </span>
                        </div>
                        
                        <div class="validation-details">
                            <div class="validation-item">
                                <span class="label">Certificado ICP-Brasil:</span>
                                <span class="value ${cert.icpValidation.icpBrasilCertificate ? 'valid' : 'invalid'}">
                                    ${cert.icpValidation.icpBrasilCertificate ? '✅ Sim' : '❌ Não'}
                                </span>
                            </div>
                            <div class="validation-item">
                                <span class="label">Validade Temporal:</span>
                                <span class="value ${cert.icpValidation.temporallyValid ? 'valid' : 'invalid'}">
                                    ${cert.icpValidation.temporallyValid ? '✅ Válido' : '❌ Inválido'}
                                </span>
                            </div>
                            <div class="validation-item">
                                <span class="label">Cadeia de Certificação:</span>
                                <span class="value ${cert.icpValidation.chainValid ? 'valid' : 'invalid'}">
                                    ${cert.icpValidation.chainValid ? '✅ Válida' : '❌ Inválida'}
                                </span>
                            </div>
                            <div class="validation-item">
                                <span class="label">Status de Revogação:</span>
                                <span class="value">${this.formatRevocationStatus(cert.icpValidation.revocationStatus)}</span>
                            </div>
                            
                            ${cert.icpValidation.cpfCnpj ? `
                                <div class="validation-item">
                                    <span class="label">CPF/CNPJ:</span>
                                    <span class="value">${this.formatCpfCnpj(cert.icpValidation.cpfCnpj)}</span>
                                </div>
                            ` : ''}
                        </div>
                        
                        ${cert.icpValidation.errors && cert.icpValidation.errors.length > 0 ? `
                            <div class="validation-errors">
                                <h5>Problemas Encontrados:</h5>
                                <ul>
                                    ${cert.icpValidation.errors.map(error => `<li>${this.escapeHtml(error)}</li>`).join('')}
                                </ul>
                            </div>
                        ` : ''}
                    </div>
                ` : ''}
                
                ${cert.tokenInfo ? `
                    <!-- Informações do Token -->
                    <div class="detail-section">
                        <h4>Token/Smartcard</h4>
                        <div class="detail-grid">
                            <div class="detail-item">
                                <span class="label">Provider:</span>
                                <span class="value">${this.escapeHtml(cert.tokenInfo.providerName)}</span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Biblioteca:</span>
                                <span class="value small">${this.escapeHtml(cert.tokenInfo.libraryPath)}</span>
                            </div>
                            ${cert.tokenInfo.tokenLabel ? `
                                <div class="detail-item">
                                    <span class="label">Label:</span>
                                    <span class="value">${this.escapeHtml(cert.tokenInfo.tokenLabel)}</span>
                                </div>
                            ` : ''}
                        </div>
                    </div>
                ` : ''}
            </div>
        `;
    }

    /**
     * Fecha modal de detalhes
     */
    closeDetailsModal() {
        this.elements.detailsModal.style.display = 'none';
        this.selectedCertificate = null;
    }

    /**
     * Seleciona certificado para uso
     */
    async selectCertificateForUse(certId) {
        const cert = this.certificates.find(c => c.alias === certId);
        if (!cert) return;
        
        if (cert.requiresPin) {
            this.showPinModal(cert);
        } else {
            await this.useCertificateDirectly(cert);
        }
    }

    /**
     * Usa certificado selecionado
     */
    async useCertificate() {
        if (!this.selectedCertificate) return;
        
        if (this.selectedCertificate.requiresPin) {
            this.closeDetailsModal();
            this.showPinModal(this.selectedCertificate);
        } else {
            await this.useCertificateDirectly(this.selectedCertificate);
        }
    }

    /**
     * Mostra modal de PIN
     */
    showPinModal(cert) {
        this.selectedCertificate = cert;
        this.elements.tokenPin.value = '';
        this.elements.pinAttempts.style.display = 'none';
        this.pinAttempts = 3;
        this.elements.pinModal.style.display = 'flex';
        this.elements.tokenPin.focus();
    }

    /**
     * Fecha modal de PIN
     */
    closePinModal() {
        this.elements.pinModal.style.display = 'none';
        this.selectedCertificate = null;
    }

    /**
     * Confirma PIN do token
     */
    async confirmPin() {
        const pin = this.elements.tokenPin.value;
        if (!pin) {
            this.showError('Digite o PIN do token');
            return;
        }
        
        try {
            this.elements.confirmPin.disabled = true;
            this.elements.confirmPin.innerHTML = '<span class="spinner"></span> Verificando...';
            
            await this.useCertificateWithPin(this.selectedCertificate, pin);
            this.closePinModal();
            
        } catch (error) {
            this.handlePinError(error);
        } finally {
            this.elements.confirmPin.disabled = false;
            this.elements.confirmPin.innerHTML = '<span class="btn-icon">🔓</span> Confirmar PIN';
        }
    }

    /**
     * Usa certificado diretamente (sem PIN)
     */
    async useCertificateDirectly(cert) {
        try {
            const requestData = {
                alias: cert.alias,
                source: cert.source,
                storeLocation: cert.storeLocation,
                requiresPin: false
            };
            
            await this.sendMessage('SELECT_CERTIFICATE', requestData);
            
            this.showSuccess(`Certificado "${cert.friendlyName || cert.alias}" selecionado com sucesso!`);
            this.closeDetailsModal();
            
            // Navegar para tela de assinatura ou fechar
            this.navigateToSigning();
            
        } catch (error) {
            this.showError(`Erro ao selecionar certificado: ${error.message}`);
        }
    }

    /**
     * Usa certificado com PIN
     */
    async useCertificateWithPin(cert, pin) {
        const requestData = {
            alias: cert.alias,
            source: cert.source,
            storeLocation: cert.storeLocation,
            requiresPin: true,
            pin: pin
        };
        
        await this.sendMessage('SELECT_CERTIFICATE', requestData);
        
        this.showSuccess(`Certificado "${cert.friendlyName || cert.alias}" selecionado com sucesso!`);
        this.navigateToSigning();
    }

    /**
     * Trata erros de PIN
     */
    handlePinError(error) {
        this.pinAttempts--;
        
        if (error.message.includes('PIN incorreto') || error.message.includes('wrong PIN')) {
            if (this.pinAttempts > 0) {
                this.elements.pinAttempts.style.display = 'block';
                this.elements.attemptsLeft.textContent = this.pinAttempts;
                this.showError(`PIN incorreto. ${this.pinAttempts} tentativas restantes.`);
            } else {
                this.showError('PIN incorreto. Máximo de tentativas excedido.');
                this.closePinModal();
            }
        } else {
            this.showError(`Erro ao acessar token: ${error.message}`);
        }
    }

    /**
     * Testa certificado
     */
    async testCertificate() {
        if (!this.selectedCertificate || !this.selectedCertificate.certificate) return;
        
        try {
            this.showTestModal();
            
            const requestData = {
                alias: this.selectedCertificate.alias,
                source: this.selectedCertificate.source
            };
            
            const response = await this.sendMessage('TEST_DISCOVERED_CERTIFICATE', requestData);
            const result = JSON.parse(response);
            
            this.showTestResult(result);
            
        } catch (error) {
            this.showTestError(error);
        }
    }

    /**
     * Mostra modal de teste
     */
    showTestModal() {
        this.elements.testModalBody.innerHTML = `
            <div class="test-progress">
                <div class="spinner"></div>
                <p>Testando certificado...</p>
            </div>
        `;
        this.elements.testModal.style.display = 'flex';
    }

    /**
     * Mostra resultado do teste
     */
    showTestResult(result) {
        const statusIcon = result.success ? '✅' : '❌';
        const statusClass = result.success ? 'success' : 'error';
        const statusText = result.success ? 'Teste realizado com sucesso!' : 'Teste falhou';
        
        this.elements.testModalBody.innerHTML = `
            <div class="test-result ${statusClass}">
                <div class="test-status">
                    <span class="status-icon">${statusIcon}</span>
                    <h4>${statusText}</h4>
                </div>
                <div class="test-details">
                    <p><strong>Mensagem:</strong> ${result.message}</p>
                    <p><strong>Certificado Válido:</strong> ${result.certificateValid ? '✅ Sim' : '❌ Não'}</p>
                    <p><strong>ICP-Brasil:</strong> ${result.icpBrasilCompliant ? '✅ Sim' : '❌ Não'}</p>
                </div>
            </div>
        `;
        
        if (result.success) {
            this.showSuccess('Certificado testado com sucesso!');
        } else {
            this.showError(`Teste falhou: ${result.message}`);
        }
    }

    /**
     * Mostra erro do teste
     */
    showTestError(error) {
        this.elements.testModalBody.innerHTML = `
            <div class="test-result error">
                <div class="test-status">
                    <span class="status-icon">❌</span>
                    <h4>Erro no teste</h4>
                </div>
                <div class="test-details">
                    <p><strong>Erro:</strong> ${error.message}</p>
                </div>
            </div>
        `;
        
        this.showError(`Erro no teste: ${error.message}`);
    }

    /**
     * Navega para tela de assinatura
     */
    navigateToSigning() {
        // Fechar janela se for popup
        if (window.opener) {
            window.close();
        } else {
            // Ou redirecionar para página principal
            window.location.href = 'popup.html';
        }
    }

    /**
     * Muda visualização (grade/lista)
     */
    changeView(view) {
        this.currentView = view;
        
        // Atualizar botões
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.view === view);
        });
        
        this.renderCertificates();
    }

    /**
     * Fecha todos os modais
     */
    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.style.display = 'none';
        });
        this.selectedCertificate = null;
    }
    
    /**
     * Abre modal de upload manual
     */
    openUploadModal() {
        // Limpar campos
        this.elements.certificateFile.value = '';
        this.elements.certificatePassword.value = '';
        this.elements.certificateAlias.value = '';
        this.elements.uploadProgress.style.display = 'none';
        
        this.elements.uploadModal.style.display = 'flex';
    }
    
    /**
     * Fecha modal de upload
     */
    closeUploadModal() {
        this.elements.uploadModal.style.display = 'none';
    }
    
    /**
     * Faz upload de certificado manual
     */
    async uploadCertificate() {
        const file = this.elements.certificateFile.files[0];
        const password = this.elements.certificatePassword.value.trim();
        const alias = this.elements.certificateAlias.value.trim() || file?.name;
        
        // Validações
        if (!file) {
            this.showError('Selecione um arquivo de certificado');
            return;
        }
        
        if (!password) {
            this.showError('Digite a senha do certificado');
            return;
        }
        
        // Verificar tipo de arquivo
        const allowedTypes = ['.p12', '.pfx'];
        const fileExtension = file.name.toLowerCase().substring(file.name.lastIndexOf('.'));
        if (!allowedTypes.includes(fileExtension)) {
            this.showError('Tipo de arquivo não suportado. Use .p12 ou .pfx');
            return;
        }
        
        try {
            // Mostrar progresso
            this.showUploadProgress();
            
            // Converter arquivo para base64
            const fileData = await this.fileToBase64(file);
            
            // Enviar para o Native Host
            const response = await this.sendMessage('INSTALL_CERTIFICATE', {
                certificateData: fileData,
                password: password,
                alias: alias,
                format: fileExtension.substring(1) // Remove o ponto
            });
            
            const result = JSON.parse(response);
            
            if (result.success) {
                this.showSuccess(`✅ Certificado "${alias}" importado com sucesso!`);
                this.closeUploadModal();
                
                // Recarregar lista de certificados
                await this.discoverCertificates(true);
            } else {
                throw new Error(result.message || 'Erro ao importar certificado');
            }
            
        } catch (error) {
            console.error('Erro no upload:', error);
            this.showError(`Erro ao importar certificado: ${error.message}`);
            this.hideUploadProgress();
        }
    }
    
    /**
     * Converte arquivo para base64
     */
    fileToBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                const base64 = reader.result.split(',')[1]; // Remove o prefixo data:...;base64,
                resolve(base64);
            };
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }
    
    /**
     * Mostra progresso do upload
     */
    showUploadProgress() {
        this.elements.uploadProgress.style.display = 'block';
        this.elements.uploadConfirmBtn.disabled = true;
        this.elements.uploadCancelBtn.disabled = true;
        
        // Simular progresso
        const progressFill = this.elements.uploadProgress.querySelector('.progress-fill');
        let progress = 0;
        const interval = setInterval(() => {
            progress += 10;
            progressFill.style.width = progress + '%';
            
            if (progress >= 90) {
                clearInterval(interval);
            }
        }, 200);
    }
    
    /**
     * Esconde progresso do upload
     */
    hideUploadProgress() {
        this.elements.uploadProgress.style.display = 'none';
        this.elements.uploadConfirmBtn.disabled = false;
        this.elements.uploadCancelBtn.disabled = false;
        
        const progressFill = this.elements.uploadProgress.querySelector('.progress-fill');
        progressFill.style.width = '0%';
    }

    /**
     * Abre modal de upload
     */
    openUploadModal() {
        // Abrir modal de upload manual ou navegar para página de upload
        window.open('certificate-manager.html', '_blank');
    }

    // Métodos utilitários

    /**
     * Obtém classe CSS baseada no status do certificado
     */
    getCertificateStatusClass(cert) {
        if (!cert.certificate) return 'token-only';
        
        const validityInfo = this.getCertificateValidityInfo(cert.certificate);
        if (!validityInfo || validityInfo.expired) return 'expired';
        
        if (validityInfo.expiringSoon) return 'expiring';
        
        return cert.icpBrasilCompliant ? 'valid-icp' : 'valid';
    }

    /**
     * Obtém ícone da fonte
     */
    getSourceIcon(source) {
        const icons = {
            'WINDOWS_STORE': '🪟',
            'MACOS_KEYCHAIN': '🍎',
            'NSS_DATABASE': '🦊',
            'PKCS11_TOKEN': '🔐',
            'FILE_SYSTEM': '📁',
            'MANUAL_UPLOAD': '📤'
        };
        return icons[source] || '📄';
    }

    /**
     * Obtém ícone de status
     */
    getStatusIcon(cert) {
        if (!cert.certificate) return '🔐';
        
        const validityInfo = this.getCertificateValidityInfo(cert.certificate);
        if (!validityInfo || validityInfo.expired) return '❌';
        
        if (validityInfo.expiringSoon) return '⚠️';
        
        return cert.icpBrasilCompliant ? '🇧🇷' : '✅';
    }

    /**
     * Obtém nome de exibição da fonte
     */
    getSourceDisplayName(source) {
        const names = {
            'WINDOWS_STORE': 'Windows Certificate Store',
            'MACOS_KEYCHAIN': 'macOS Keychain',
            'NSS_DATABASE': 'Firefox/Chrome',
            'PKCS11_TOKEN': 'Token/Smartcard',
            'FILE_SYSTEM': 'Sistema de Arquivos',
            'MANUAL_UPLOAD': 'Upload Manual'
        };
        return names[source] || source;
    }

    /**
     * Obtém badge visual da fonte do certificado
     */
    getSourceBadge(source) {
        const badges = {
            'WINDOWS_STORE': '<span class="badge source-discovered">🪟 Descoberto</span>',
            'MACOS_KEYCHAIN': '<span class="badge source-discovered">🍎 Descoberto</span>',
            'NSS_DATABASE': '<span class="badge source-discovered">🦊 Descoberto</span>',
            'PKCS11_TOKEN': '<span class="badge source-discovered">🔐 Token</span>',
            'FILE_SYSTEM': '<span class="badge source-discovered">📁 Descoberto</span>',
            'MANUAL_UPLOAD': '<span class="badge source-uploaded">📤 Upload</span>'
        };
        return badges[source] || '<span class="badge source-unknown">❓ Desconhecido</span>';
    }

    /**
     * Obtém informações de validade do certificado
     */
    getCertificateValidityInfo(certificate) {
        if (!certificate) return null;
        
        try {
            const now = new Date();
            const notBefore = new Date(certificate.notBefore);
            const notAfter = new Date(certificate.notAfter);
            
            const expired = notAfter < now;
            const expiringSoon = !expired && (notAfter - now) <= (30 * 24 * 60 * 60 * 1000); // 30 dias
            
            return {
                subject: certificate.subject || '',
                issuer: certificate.issuer || '',
                serialNumber: certificate.serialNumber || '',
                notBefore: this.formatDate(notBefore),
                notAfter: this.formatDate(notAfter),
                expired: expired,
                expiringSoon: expiringSoon
            };
        } catch (error) {
            return null;
        }
    }

    /**
     * Formata status de revogação
     */
    formatRevocationStatus(status) {
        const statuses = {
            'GOOD': '✅ Não revogado',
            'REVOKED': '❌ Revogado',
            'UNKNOWN': '⚠️ Status desconhecido'
        };
        return statuses[status] || status;
    }

    /**
     * Formata CPF/CNPJ
     */
    formatCpfCnpj(cpfCnpj) {
        if (!cpfCnpj) return '';
        
        const numbers = cpfCnpj.replace(/\D/g, '');
        
        if (numbers.length === 11) {
            return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
        } else if (numbers.length === 14) {
            return numbers.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
        }
        
        return cpfCnpj;
    }

    /**
     * Extrai Common Name do Distinguished Name
     */
    extractCN(dn) {
        if (!dn) return '';
        const match = dn.match(/CN=([^,]+)/);
        return match ? match[1].trim() : dn;
    }

    /**
     * Formata data
     */
    formatDate(date) {
        return date.toLocaleDateString('pt-BR');
    }

    /**
     * Escapa HTML
     */
    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Mostra modal quando Native Host não está instalado
     */
    showHostNotInstalledModal() {
        const modal = document.createElement('div');
        modal.className = 'host-not-installed-modal';
        modal.innerHTML = `
            <div class="modal-overlay"></div>
            <div class="modal-content">
                <div class="modal-icon">⚠️</div>
                <h2>FluxSigner Native Host Não Instalado</h2>
                <p>Para usar o FluxSigner, você precisa instalar o Native Host (componente de backend).</p>
                
                <div class="install-steps">
                    <h3>Como Instalar:</h3>
                    <ol>
                        <li>Baixe o instalador <strong>FluxSignerSetup.exe</strong></li>
                        <li>Execute o instalador como Administrador</li>
                        <li>Após a instalação, reinicie o navegador</li>
                        <li>Volte aqui e clique em "Atualizar Certificados"</li>
                    </ol>
                </div>
                
                <div class="modal-actions">
                    <a href="https://github.com/fluxmed/fluxsigner-support/releases/latest" 
                       target="_blank" 
                       class="btn btn-primary">
                        📥 Baixar Instalador
                    </a>
                    <button class="btn btn-secondary" onclick="this.closest('.host-not-installed-modal').remove()">
                        Fechar
                    </button>
                </div>
                
                <div class="help-link">
                    <a href="https://github.com/fluxmed/fluxsigner-support#instalação" target="_blank">
                        Ver guia completo de instalação
                    </a>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
    }

    /**
     * Envia mensagem para native host
     */
    async sendMessage(action, data = null) {
        return new Promise((resolve, reject) => {
            const message = {
                action: action,
                requestId: 'cert-discovery-' + Date.now(),
                data: data
            };
            
            chrome.runtime.sendMessage(message, (response) => {
                if (chrome.runtime.lastError) {
                    // Se for erro de "Native host has exited", tratar silenciosamente
                    if (chrome.runtime.lastError.message.includes('Native host has exited')) {
                        console.warn('Native Host finalizou inesperadamente, mas operação pode ter sido concluída');
                        // Retornar resposta padrão para evitar erro visual
                        resolve('{"success": false, "message": "Native Host finalizou"}');
                        return;
                    }
                    // Outros erros são tratados normalmente
                    reject(new Error(chrome.runtime.lastError.message));
                    return;
                }
                
                if (response && response.status === 'SUCCESS') {
                    resolve(response.message);
                } else {
                    reject(new Error(response ? response.message : 'Erro de comunicação'));
                }
            });
        });
    }

    /**
     * Mostra notificação de sucesso
     */
    showSuccess(message) {
        this.showNotification(message, 'success');
    }

    /**
     * Mostra notificação de erro
     */
    showError(message) {
        this.showNotification(message, 'error');
    }

    /**
     * Mostra notificação
     */
    showNotification(message, type) {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        
        const iconMap = {
            'success': '✅',
            'error': '❌',
            'warning': '⚠️',
            'info': 'ℹ️'
        };
        
        notification.innerHTML = `
            <span class="notification-icon">${iconMap[type] || 'ℹ️'}</span>
            <span class="notification-message">${this.escapeHtml(message)}</span>
            <button class="notification-close">×</button>
        `;

        this.elements.notificationsContainer.appendChild(notification);

        // Event listener para fechar
        notification.querySelector('.notification-close').addEventListener('click', () => {
            notification.remove();
        });

        // Auto-remover após 5 segundos
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }

    /**
     * Log de debug
     */
    log(message) {
        console.log(`[CertificateDiscovery] ${message}`);
    }
}

// Inicializar quando a página carregar
document.addEventListener('DOMContentLoaded', () => {
    new CertificateDiscovery();
});
