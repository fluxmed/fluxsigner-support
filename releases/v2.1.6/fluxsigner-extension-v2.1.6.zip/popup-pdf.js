/**
 * FluxSigner Popup PDF Script
 * Gerencia a interface de assinatura digital de documentos PDF
 */

// Estado global da aplicação
let currentDocument = {
    content: '',
    fileName: '',
    signedContent: '',
    signatureCount: 0
};

// Elementos DOM
let elements = {};

// Inicialização quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    initializeElements();
    setupEventListeners();
    loadCertificates();
    updateStatus('Pronto para assinar documentos PDF com certificados ICP-Brasil', 'info');
});

/**
 * Inicializa referências aos elementos DOM
 */
function initializeElements() {
    elements = {
        fileInput: document.getElementById('fileInput'),
        fileInfo: document.getElementById('fileInfo'),
        fileName: document.getElementById('fileName'),
        fileSize: document.getElementById('fileSize'),
        signatureCount: document.getElementById('signatureCount'),
        refreshCertsBtn: document.getElementById('refreshCertsBtn'),
        certificateSelect: document.getElementById('certificateSelect'),
        certDetails: document.getElementById('certDetails'),
        signButton: document.getElementById('signButton'),
        verifyButton: document.getElementById('verifyButton'),
        verificationResults: document.getElementById('verificationResults'),
        signatureStatus: document.getElementById('signatureStatus'),
        downloadButton: document.getElementById('downloadButton'),
        log: document.getElementById('log'),
        clearLogBtn: document.getElementById('clearLogBtn')
    };
}

/**
 * Configura os event listeners
 */
function setupEventListeners() {
    // Seleção de arquivo para assinatura
    elements.fileInput.addEventListener('change', handleFileSelection);
    
    // Botão de atualizar certificados
    elements.refreshCertsBtn.addEventListener('click', loadCertificates);
    
    // Seleção de certificado
    elements.certificateSelect.addEventListener('change', handleCertificateSelection);
    
    // Botão de assinar
    elements.signButton.addEventListener('click', handleSignDocument);
    
    // Botão de verificar
    elements.verifyButton.addEventListener('click', handleVerifySignatures);
    
    // Botão de download
    elements.downloadButton.addEventListener('click', handleDownloadSigned);
    
    // Botão de limpar log
    elements.clearLogBtn.addEventListener('click', clearLog);
}

/**
 * Carrega certificados disponíveis
 */
async function loadCertificates() {
    try {
        log('Carregando certificados...', 'info');
        elements.certificateSelect.disabled = true;
        elements.certificateSelect.innerHTML = '<option value="">Carregando certificados...</option>';
        
        const response = await sendMessage({
            action: 'GET_CERTIFICATES',
            requestId: generateRequestId()
        });
        
        if (response.status === 'SUCCESS') {
            const data = JSON.parse(response.message);
            const icpBrasilCount = data.certificates.filter(cert => cert.icpBrasilCompliant === true).length;
            populateCertificateSelect(data.certificates);
            log(`Certificados ICP-Brasil encontrados: ${icpBrasilCount} de ${data.count} certificados`, 'success');
        } else {
            throw new Error(response.message || 'Erro ao carregar certificados');
        }
        
    } catch (error) {
        log(`Erro ao carregar certificados: ${error.message}`, 'error');
        elements.certificateSelect.innerHTML = '<option value="">Erro ao carregar certificados</option>';
        
        // Verificar se é erro de host não instalado
        if (error.message === 'HOST_NOT_INSTALLED') {
            showHostNotInstalledAlert();
        } else {
            showError('Erro ao carregar certificados: ' + error.message);
        }
    } finally {
        elements.certificateSelect.disabled = false;
    }
}

/**
 * Popula o select de certificados
 * Filtra para mostrar apenas certificados ICP-Brasil
 */
function populateCertificateSelect(certificates) {
    elements.certificateSelect.innerHTML = '<option value="">Selecione um certificado...</option>';
    
    // Filtrar apenas certificados ICP-Brasil
    const icpBrasilCerts = certificates.filter(cert => cert.icpBrasilCompliant === true);
    
    if (icpBrasilCerts.length === 0) {
        elements.certificateSelect.innerHTML = '<option value="">Nenhum certificado encontrado</option>';
        log('Nenhum certificado ICP-Brasil encontrado. Certifique-se de ter um certificado digital válido instalado.', 'warning');
        return;
    }
    
    icpBrasilCerts.forEach(cert => {
        const option = document.createElement('option');
        option.value = cert.alias;
        
        // Extrair nome da Autoridade Certificadora (CA) do issuer
        const caName = extractCAName(cert.issuer);
        
        // Criar texto mais informativo e limpo
        // Formato: NOME DO TITULAR | CA EMISSORA | TIPO | Validade
        const typeInfo = cert.certificateType ? ` | ${cert.certificateType}` : '';
        const validityInfo = cert.daysUntilExpiry > 0 ? ` | Válido: ${cert.daysUntilExpiry} dias` : '';
        const caInfo = caName ? ` | ${caName}` : '';
        
        option.textContent = `${cert.commonName}${caInfo}${typeInfo}${validityInfo}`;
        option.dataset.cert = JSON.stringify(cert);
        elements.certificateSelect.appendChild(option);
    });
    
    if (certificates.length === 0) {
        elements.certificateSelect.innerHTML = '<option value="">Nenhum certificado válido encontrado</option>';
    }
}

/**
 * Extrai o nome da Autoridade Certificadora (CA) do campo issuer
 * Exemplo de issuer: "CN=AC VALID RFB v5, OU=Secretaria da Receita Federal do Brasil - RFB, O=ICP-Brasil, C=BR"
 * Retorna apenas o nome principal da CA (ex: "VALID", "Serasa", "Certisign")
 */
function extractCAName(issuer) {
    if (!issuer) return null;
    
    try {
        // Extrair o CN (Common Name) do issuer
        const cnMatch = issuer.match(/CN=([^,]+)/i);
        if (!cnMatch) return null;
        
        let cn = cnMatch[1].trim();
        
        // Mapear nomes conhecidos de CAs ICP-Brasil para formato amigável
        const caMap = {
            'VALID': 'VALID',
            'SERASA': 'Serasa',
            'CERTISIGN': 'Certisign',
            'SAFEWEB': 'Safeweb',
            'SOLUTI': 'Soluti',
            'FENACON': 'Fenacon',
            'PRODEMGE': 'Prodemge',
            'NOTARIAL': 'Notarial',
            'SINCOR': 'Sincor',
            'DIGITALSIGN': 'DigitalSign',
            'SERPRO': 'Serpro',
            'CAIXA': 'Caixa',
            'CORREIOS': 'Correios'
        };
        
        // Procurar nome da CA no CN
        for (const [key, value] of Object.entries(caMap)) {
            if (cn.toUpperCase().includes(key)) {
                return value;
            }
        }
        
        // Se não encontrou um nome conhecido, tentar extrair o primeiro termo significativo
        // Remove "AC " (Autoridade Certificadora) do início
        cn = cn.replace(/^AC\s+/i, '');
        
        // Pegar primeira palavra (geralmente é o nome da CA)
        const firstWord = cn.split(/\s+/)[0];
        
        // Se for muito curto ou genérico, retornar null
        if (firstWord.length < 3 || ['RFB', 'ICP', 'BR'].includes(firstWord.toUpperCase())) {
            return null;
        }
        
        return firstWord;
        
    } catch (error) {
        console.warn('Erro ao extrair nome da CA:', error);
        return null;
    }
}

/**
 * Obtém ícone do fornecedor
 */
function getProviderIcon(providerName) {
    const icons = {
        'Receita Federal do Brasil (RFB)': '🏛️',
        'SOLUTI': '🔐',
        'SERASA': '📊',
        'SERPRO': '🏢',
        'CERTISIGN': '✅',
        'Imprensa Oficial': '📰',
        'CAIXA': '🏦',
        'Banco do Brasil': '🏦',
        'VALID': '✓',
        'ICP-Brasil (Outros)': '🇧🇷',
        'Microsoft Windows': '🪟',
        'Desconhecido': '❓'
    };
    return icons[providerName] || '❓';
}

/**
 * Obtém ícone de validade
 */
function getValidityIcon(validityStatus) {
    const icons = {
        'Válido': '✅',
        'Expira em breve': '⚠️',
        'Expirado': '❌'
    };
    return icons[validityStatus] || '❓';
}

/**
 * Manipula seleção de certificado
 */
function handleCertificateSelection(event) {
    const selectedOption = event.target.selectedOptions[0];
    
    if (selectedOption && selectedOption.value) {
        const cert = JSON.parse(selectedOption.dataset.cert);
        displayCertificateDetails(cert);
        enableSignButton();
    } else {
        hideCertificateDetails();
        disableSignButton();
    }
}

/**
 * Exibe detalhes do certificado selecionado
 */
function displayCertificateDetails(cert) {
    const providerIcon = getProviderIcon(cert.providerName);
    const validityIcon = getValidityIcon(cert.validityStatus);
    const icpIcon = cert.icpBrasilCompliant ? '🇧🇷' : '⚪';
    
    const details = `
        <h4>📋 Detalhes do Certificado</h4>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 13px;">
            <div>
                <p><strong>👤 Titular:</strong> ${cert.commonName}</p>
                <p><strong>${providerIcon} Fornecedor:</strong> ${cert.providerName}</p>
                <p><strong>📄 Tipo:</strong> ${cert.certificateType || 'N/A'}</p>
                <p><strong>${icpIcon} ICP-Brasil:</strong> ${cert.icpBrasilCompliant ? 'Sim' : 'Não'}</p>
            </div>
            <div>
                <p><strong>🏛️ Emissor:</strong> ${extractCN(cert.issuer)}</p>
                <p><strong>📅 Válido até:</strong> ${formatDate(cert.notAfter)}</p>
                <p><strong>${validityIcon} Status:</strong> ${cert.validityStatus}</p>
                <p><strong>🔑 Chave Privada:</strong> ${cert.hasPrivateKey ? '✅ Disponível' : '❌ Não disponível'}</p>
            </div>
        </div>
        ${cert.daysUntilExpiry > 0 ? `
            <div style="margin-top: 10px; padding: 8px; background: ${cert.daysUntilExpiry <= 30 ? '#fff3cd' : '#d4edda'}; border-radius: 4px; font-size: 12px;">
                <strong>⏰ Validade:</strong> ${cert.daysUntilExpiry} dias restantes
                ${cert.daysUntilExpiry <= 30 ? ' ⚠️ Expira em breve!' : ''}
            </div>
        ` : ''}
        ${cert.requiresPin ? `
            <div style="margin-top: 10px; padding: 8px; background: #d1ecf1; border-radius: 4px; font-size: 12px;">
                <strong>🔐 Token:</strong> Requer PIN para uso
            </div>
        ` : ''}
    `;
    
    elements.certDetails.innerHTML = details;
    elements.certDetails.style.display = 'block';
}

/**
 * Esconde detalhes do certificado
 */
function hideCertificateDetails() {
    elements.certDetails.style.display = 'none';
}

/**
 * Habilita o botão de assinar
 */
function enableSignButton() {
    elements.signButton.disabled = false;
}

/**
 * Desabilita o botão de assinar
 */
function disableSignButton() {
    elements.signButton.disabled = true;
}

/**
 * Manipula a seleção de arquivo para assinatura
 */
function handleFileSelection(event) {
    const file = event.target.files[0];
    
    if (!file) {
        resetDocumentState();
        return;
    }
    
    // Validar tipo de arquivo
    if (!file.name.toLowerCase().endsWith('.pdf')) {
        showError('Apenas arquivos PDF são suportados');
        elements.fileInput.value = '';
        return;
    }
    
    // Validar tamanho (máximo 10MB)
    if (file.size > 10 * 1024 * 1024) {
        showError('Arquivo muito grande. Máximo permitido: 10MB');
        elements.fileInput.value = '';
        return;
    }
    
    // Ler conteúdo do arquivo
    const reader = new FileReader();
    reader.onload = function(e) {
        // Extrair apenas a parte Base64, removendo o prefixo data:application/pdf;base64,
        const dataUrl = e.target.result;
        const base64Data = dataUrl.split(',')[1];
        
        // Validar se o Base64 é válido
        if (!base64Data || !isValidBase64(base64Data)) {
            showError('Erro ao processar arquivo PDF');
            resetDocumentState();
            return;
        }
        
        currentDocument.content = base64Data;
        currentDocument.fileName = file.name;
        
        displayFileInfo(file);
        checkExistingSignatures();
        
        updateStatus(`Documento "${file.name}" carregado com sucesso`, 'success');
    };
    
    reader.onerror = function() {
        showError('Erro ao ler o arquivo');
        resetDocumentState();
    };
    
    reader.readAsDataURL(file);
}

/**
 * Exibe informações do arquivo selecionado
 */
function displayFileInfo(file) {
    elements.fileName.textContent = file.name;
    elements.fileSize.textContent = file.size.toLocaleString();
    elements.fileInfo.style.display = 'block';
}

/**
 * Verifica assinaturas existentes no PDF
 */
async function checkExistingSignatures() {
    try {
        log('Verificando assinaturas existentes...', 'info');
        elements.signatureCount.textContent = 'Verificando...';
        
        const response = await sendMessage({
            action: 'VERIFY_PDF_SIGNATURES',
            requestId: generateRequestId(),
            data: {
                content: currentDocument.content
            }
        });
        
        if (response.status === 'SUCCESS') {
            const data = JSON.parse(response.message);
            currentDocument.signatureCount = data.signatures ? data.signatures.length : 0;
            
            if (currentDocument.signatureCount > 0) {
                elements.signatureCount.innerHTML = `<span class="signature-count has-signatures">${currentDocument.signatureCount} assinatura(s) encontrada(s)</span>`;
                elements.verifyButton.disabled = false;
                log(`Assinaturas encontradas: ${currentDocument.signatureCount}`, 'info');
            } else {
                elements.signatureCount.innerHTML = '<span class="signature-count no-signatures">Nenhuma assinatura</span>';
                elements.verifyButton.disabled = true;
                log('Nenhuma assinatura encontrada no documento', 'info');
            }
        } else {
            const errorMsg = response ? response.message : 'Resposta inválida do servidor';
            elements.signatureCount.textContent = 'Erro na verificação';
            log(`Erro ao verificar assinaturas: ${errorMsg}`, 'error');
        }
        
    } catch (error) {
        console.error('Erro ao verificar assinaturas:', error);
        elements.signatureCount.textContent = 'Erro na verificação';
        log(`Erro ao verificar assinaturas: ${error.message}`, 'error');
        
        // Não bloquear o processo por erro de verificação
        log('Continuando sem verificação de assinaturas existentes', 'info');
    }
}

/**
 * Manipula o processo de assinatura do documento
 */
async function handleSignDocument() {
    if (!currentDocument.content) {
        showError('Nenhum documento selecionado');
        return;
    }
    
    const selectedCert = elements.certificateSelect.value;
    if (!selectedCert) {
        showError('Selecione um certificado');
        return;
    }
    
    try {
        // Mostrar status de processamento
        showSigningProgress();
        
        // Configurações fixas para assinatura profissional
        const request = {
            action: 'SIGN_PDF',
            requestId: generateRequestId(),
            data: {
                content: currentDocument.content,
                fileName: currentDocument.fileName,
                certificateAlias: selectedCert,
                reason: 'Assinado digitalmente', // Valor fixo, simples e profissional
                location: 'Brasil', // Valor fixo para conformidade ICP-Brasil
                useTimestamp: true // TSA sempre habilitado para validade jurídica completa
            }
        };
        
        updateStatus('Enviando documento para assinatura...', 'info');
        log('Iniciando assinatura PDF com carimbo de tempo TSA...', 'info');
        
        const response = await sendMessage(request);
        
        if (response.status === 'SUCCESS') {
            handleSignatureSuccess(response);
        } else {
            handleSignatureError(response);
        }
        
    } catch (error) {
        console.error('Erro durante assinatura:', error);
        log(`Erro durante assinatura: ${error.message}`, 'error');
        showError('Erro durante assinatura: ' + error.message);
    } finally {
        hideSigningProgress();
    }
}

/**
 * Mostra progresso da assinatura
 */
function showSigningProgress() {
    elements.signButton.disabled = true;
    elements.signButton.innerHTML = '<span class="loading"></span>Assinando...';
}

/**
 * Esconde progresso da assinatura
 */
function hideSigningProgress() {
    elements.signButton.disabled = false;
    elements.signButton.innerHTML = 'Assinar PDF';
}

/**
 * Manipula sucesso na assinatura
 */
function handleSignatureSuccess(response) {
    const data = JSON.parse(response.message);
    
    // Armazenar documento assinado
    currentDocument.signedContent = data.signedPdfData;
    
    // Exibir status da assinatura
    elements.signatureStatus.innerHTML = `
        <strong>✅ Documento assinado com sucesso!</strong><br>
        ${data.timestampUsed ? '📅 Timestamp TSA aplicado' : '📄 Assinatura sem timestamp'}<br>
        <em>Certificado: ${data.certificateInfo.subject}</em>
    `;
    elements.signatureStatus.className = 'status success';
    elements.signatureStatus.style.display = 'block';
    
    // Habilitar botão de download (mantido caso usuário queira baixar novamente)
    elements.downloadButton.style.display = 'block';
    
    // Habilitar verificação
    elements.verifyButton.disabled = false;
    
    updateStatus('Documento assinado com sucesso! Iniciando download...', 'success');
    log('Documento assinado com sucesso! Iniciando download automático...', 'success');
    
    // Download automático do documento assinado
    setTimeout(() => {
        downloadSignedDocument();
    }, 500); // Pequeno delay para garantir que o usuário veja a mensagem de sucesso
}

/**
 * Manipula erro na assinatura
 */
function handleSignatureError(response) {
    const errorMessage = response.message || 'Erro desconhecido';
    log(`Erro na assinatura: ${errorMessage}`, 'error');
    showError('Falha na assinatura: ' + errorMessage);
}

/**
 * Manipula verificação de assinaturas
 */
async function handleVerifySignatures() {
    if (!currentDocument.content) {
        showError('Nenhum documento selecionado para verificação');
        return;
    }
    
    try {
        updateStatus('Verificando assinaturas...', 'info');
        log('Iniciando verificação de assinaturas...', 'info');
        
        const response = await sendMessage({
            action: 'VERIFY_PDF_SIGNATURES',
            requestId: generateRequestId(),
            data: {
                content: currentDocument.signedContent || currentDocument.content
            }
        });
        
        if (response && response.status === 'SUCCESS') {
            const data = JSON.parse(response.message);
            displayVerificationResults(data);
        } else {
            const errorMsg = response ? response.message : 'Resposta inválida do servidor';
            showError('Erro na verificação: ' + errorMsg);
        }
        
    } catch (error) {
        console.error('Erro durante verificação:', error);
        log(`Erro durante verificação: ${error.message}`, 'error');
        showError('Erro durante verificação: ' + error.message);
    }
}

/**
 * Exibe resultados da verificação
 */
function displayVerificationResults(data) {
    const resultsDiv = elements.verificationResults;
    
    if (!data.signatures || data.signatures.length === 0) {
        resultsDiv.innerHTML = '<div class="status warning">⚠️ Nenhuma assinatura encontrada no documento</div>';
        return;
    }
    
    let html = `<h4>📋 Resultados da Verificação (${data.signatures.length} assinatura(s))</h4>`;
    
    data.signatures.forEach((signature, index) => {
        const statusClass = signature.integrityValid ? 'valid' : 'invalid';
        const statusIcon = signature.integrityValid ? '✅' : '❌';
        const statusText = signature.integrityValid ? 'Válida' : 'Inválida';
        
        // Extrair informações do certificado
        let subject = 'N/A';
        let issuer = 'N/A';
        let signingTime = 'N/A';
        
        try {
            if (signature.certificateInfo) {
                const certInfo = JSON.parse(signature.certificateInfo);
                subject = certInfo.subject || 'N/A';
                issuer = certInfo.issuer || 'N/A';
            }
        } catch (e) {
            console.warn('Erro ao parsear certificateInfo:', e);
        }
        
        if (signature.signDate) {
            signingTime = formatDate(signature.signDate);
        }
        
        html += `
            <div class="signature-item ${statusClass}">
                <h4>${statusIcon} Assinatura ${index + 1} - ${statusText}</h4>
                <p><strong>Titular:</strong> ${subject}</p>
                <p><strong>Emissor:</strong> ${issuer}</p>
                <p><strong>Data:</strong> ${signingTime}</p>
                <p><strong>Motivo:</strong> ${signature.reason || 'N/A'}</p>
                <p><strong>Local:</strong> ${signature.location || 'N/A'}</p>
                ${signature.hasTimestamp ? `
                    <p><strong>Timestamp:</strong> ✅ Presente (${formatDate(signature.timestampValidationResult.timestamp)})</p>
                ` : '<p><strong>Timestamp:</strong> ❌ Não presente</p>'}
                
                ${signature.icpValidationResult ? `
                    <div class="icp-validation">
                        <h5>🇧🇷 Validação ICP-Brasil</h5>
                        <p><strong>Status:</strong> ${signature.icpValidationResult.valid ? '✅ Válido' : '❌ Inválido'}</p>
                        <p><strong>Certificado ICP:</strong> ${signature.icpValidationResult.icpBrasilCertificate ? '✅ Sim' : '❌ Não'}</p>
                        <p><strong>Validade Temporal:</strong> ${signature.icpValidationResult.temporallyValid ? '✅ Válido' : '❌ Inválido'}</p>
                        <p><strong>Cadeia:</strong> ${signature.icpValidationResult.chainValid ? '✅ Válida' : '❌ Inválida'}</p>
                        ${signature.icpValidationResult.errors && signature.icpValidationResult.errors.length > 0 ? `
                            <p class="errors"><strong>Erros:</strong> ${signature.icpValidationResult.errors.join(', ')}</p>
                        ` : ''}
                    </div>
                ` : ''}
            </div>
        `;
    });
    
    resultsDiv.innerHTML = html;
    updateStatus('Verificação concluída!', 'success');
    log('Verificação de assinaturas concluída', 'success');
}

/**
 * Faz download do documento assinado (função reutilizável)
 */
function downloadSignedDocument() {
    if (!currentDocument.signedContent) {
        showError('Nenhum documento assinado disponível');
        return;
    }
    
    // Converter base64 para blob
    const byteCharacters = atob(currentDocument.signedContent);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: 'application/pdf' });
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = getSignedFileName(currentDocument.fileName);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    
    URL.revokeObjectURL(url);
    updateStatus('Download iniciado!', 'success');
    log('Download do documento assinado iniciado', 'success');
}

/**
 * Manipula clique no botão de download (event handler)
 */
function handleDownloadSigned() {
    downloadSignedDocument();
}

/**
 * Gera nome do arquivo assinado
 */
function getSignedFileName(originalName) {
    const nameWithoutExt = originalName.replace(/\.pdf$/i, '');
    const timestamp = new Date().toISOString().slice(0, 19).replace(/[:.]/g, '-');
    return `${nameWithoutExt}_assinado_${timestamp}.pdf`;
}

/**
 * Abre gerenciador de certificados
 * DESABILITADO: Funcionalidade de upload de certificados A1 será implementada em fase futura
 */
/*
function openCertificateManager() {
    chrome.tabs.create({ url: chrome.runtime.getURL('certificate-discovery.html') });
}
*/

/**
 * Envia mensagem para o native host
 */
function sendMessage(message) {
    return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(message, (response) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            } else if (response && response.error) {
                reject(new Error(response.error));
            } else {
                resolve(response);
            }
        });
    });
}

/**
 * Gera ID único para requisições
 */
function generateRequestId() {
    return 'req_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

/**
 * Mostra alerta quando Native Host não está instalado
 */
function showHostNotInstalledAlert() {
    const message = 'O FluxSigner Native Host não está instalado.\n\n' +
                    'Para usar o FluxSigner, você precisa:\n' +
                    '1. Baixar o instalador FluxSignerSetup.exe\n' +
                    '2. Executar como Administrador\n' +
                    '3. Reiniciar o navegador\n\n' +
                    'Clique em OK para baixar o instalador.';
    
    if (confirm(message)) {
        window.open('https://github.com/fluxmed/fluxsigner-support/releases/latest', '_blank');
    }
}

/**
 * Valida se uma string é Base64 válida
 */
function isValidBase64(str) {
    try {
        // Verificar se contém apenas caracteres Base64 válidos
        const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
        if (!base64Regex.test(str)) {
            return false;
        }
        
        // Tentar decodificar para verificar se é válido
        atob(str);
        return true;
    } catch (e) {
        return false;
    }
}

/**
 * Reseta o estado do documento
 */
function resetDocumentState() {
    currentDocument = { content: '', fileName: '', signedContent: '', signatureCount: 0 };
    elements.fileInfo.style.display = 'none';
    elements.signatureStatus.style.display = 'none';
    elements.downloadButton.style.display = 'none';
    elements.verificationResults.innerHTML = '';
    elements.verifyButton.disabled = true;
    disableSignButton();
}

/**
 * Mostra mensagem de erro
 */
function showError(message) {
    updateStatus(message, 'error');
    console.error('FluxSigner Error:', message);
}

/**
 * Atualiza status geral da aplicação
 */
function updateStatus(message, type = 'info') {
    // Criar elemento de status se não existir
    let statusElement = document.getElementById('generalStatus');
    if (!statusElement) {
        statusElement = document.createElement('div');
        statusElement.id = 'generalStatus';
        statusElement.className = 'status';
        document.body.insertBefore(statusElement, document.body.firstChild);
    }
    
    statusElement.textContent = message;
    statusElement.className = `status ${type}`;
    statusElement.style.display = 'block';
    
    // Auto-ocultar mensagens de sucesso após 3 segundos
    if (type === 'success') {
        setTimeout(() => {
            statusElement.style.display = 'none';
        }, 3000);
    }
}

/**
 * Log de atividades
 */
function log(message, type = 'info') {
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = document.createElement('div');
    logEntry.className = 'log-entry';
    
    const typeIcon = {
        'success': '✅',
        'error': '❌',
        'warning': '⚠️',
        'info': 'ℹ️'
    }[type] || 'ℹ️';
    
    logEntry.innerHTML = `[${timestamp}] ${typeIcon} ${message}`;
    elements.log.appendChild(logEntry);
    elements.log.scrollTop = elements.log.scrollHeight;
    
    // Limitar número de entradas
    const entries = elements.log.querySelectorAll('.log-entry');
    if (entries.length > 50) {
        entries[0].remove();
    }
}

/**
 * Limpa o log
 */
function clearLog() {
    elements.log.innerHTML = '';
    log('Log limpo', 'info');
}

/**
 * Extrai Common Name do Distinguished Name
 */
function extractCN(dn) {
    if (!dn) return '';
    const match = dn.match(/CN=([^,]+)/);
    return match ? match[1].trim() : dn;
}

/**
 * Formata data
 */
function formatDate(timestamp) {
    if (!timestamp) return 'N/A';
    return new Date(timestamp).toLocaleString('pt-BR');
}
