/**
 * FluxSigner Popup Script
 * Gerencia a interface de assinatura digital de documentos
 */

// Estado global da aplicação
let currentDocument = {
    content: '',
    fileName: '',
    signedContent: ''
};

// Elementos DOM
let elements = {};

// Inicialização quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    initializeElements();
    setupEventListeners();
    updateStatus('Pronto para assinar documentos', 'info');
});

/**
 * Inicializa referências aos elementos DOM
 */
function initializeElements() {
    elements = {
        fileInput: document.getElementById('fileInput'),
        fileInfo: document.getElementById('fileInfo'),
        fileName: document.getElementById('fileName'),
        fileSize: document.getElementById('fileSize'),
        documentContent: document.getElementById('documentContent'),
        signButton: document.getElementById('signButton'),
        signingStatus: document.getElementById('signingStatus'),
        certInfo: document.getElementById('certInfo'),
        certDetails: document.getElementById('certDetails'),
        signedContent: document.getElementById('signedContent'),
        downloadButton: document.getElementById('downloadButton'),
        copyButton: document.getElementById('copyButton'),
        verifyButton: document.getElementById('verifyButton'),
        loadSignedButton: document.getElementById('loadSignedButton'),
        signedFileInput: document.getElementById('signedFileInput'),
        verificationResult: document.getElementById('verificationResult'),
        generalStatus: document.getElementById('generalStatus'),
        statusMessage: document.getElementById('statusMessage')
    };
}

/**
 * Configura os event listeners
 */
function setupEventListeners() {
    // Seleção de arquivo para assinatura
    elements.fileInput.addEventListener('change', handleFileSelection);
    
    // Botão de assinar
    elements.signButton.addEventListener('click', handleSignDocument);
    
    // Botão de download
    elements.downloadButton.addEventListener('click', handleDownloadSigned);
    
    // Botão de copiar
    elements.copyButton.addEventListener('click', handleCopyToClipboard);
    
    // Botão de verificar
    elements.verifyButton.addEventListener('click', handleVerifySignature);
    
    // Botão de carregar documento assinado
    elements.loadSignedButton.addEventListener('click', () => {
        elements.signedFileInput.click();
    });
    
    // Seleção de arquivo assinado para verificação
    elements.signedFileInput.addEventListener('change', handleSignedFileSelection);
}

/**
 * Manipula a seleção de arquivo para assinatura
 */
function handleFileSelection(event) {
    const file = event.target.files[0];
    
    if (!file) {
        resetDocumentState();
        return;
    }
    
    // Validar tipo de arquivo
    if (!file.name.toLowerCase().endsWith('.txt')) {
        showError('Apenas arquivos .txt são suportados nesta versão');
        elements.fileInput.value = '';
        return;
    }
    
    // Validar tamanho (máximo 1MB)
    if (file.size > 1024 * 1024) {
        showError('Arquivo muito grande. Máximo permitido: 1MB');
        elements.fileInput.value = '';
        return;
    }
    
    // Ler conteúdo do arquivo
    const reader = new FileReader();
    reader.onload = function(e) {
        currentDocument.content = e.target.result;
        currentDocument.fileName = file.name;
        
        displayFileInfo(file);
        displayDocumentContent(currentDocument.content);
        enableSignButton();
        
        updateStatus(`Documento "${file.name}" carregado com sucesso`, 'success');
    };
    
    reader.onerror = function() {
        showError('Erro ao ler o arquivo');
        resetDocumentState();
    };
    
    reader.readAsText(file, 'UTF-8');
}

/**
 * Exibe informações do arquivo selecionado
 */
function displayFileInfo(file) {
    elements.fileName.textContent = file.name;
    elements.fileSize.textContent = file.size.toLocaleString();
    elements.fileInfo.classList.remove('hidden');
}

/**
 * Exibe o conteúdo do documento na textarea
 */
function displayDocumentContent(content) {
    elements.documentContent.value = content;
}

/**
 * Habilita o botão de assinar
 */
function enableSignButton() {
    elements.signButton.disabled = false;
}

/**
 * Manipula o processo de assinatura do documento
 */
async function handleSignDocument() {
    if (!currentDocument.content) {
        showError('Nenhum documento selecionado');
        return;
    }
    
    try {
        // Mostrar status de processamento
        showSigningProgress();
        
        // Enviar requisição para o native host
        const request = {
            action: 'SIGN_DOCUMENT',
            requestId: generateRequestId(),
            data: {
                content: currentDocument.content,
                fileName: currentDocument.fileName,
                timestamp: Date.now()
            }
        };
        
        updateStatus('Enviando documento para assinatura...', 'info');
        
        const response = await sendNativeMessage(request);
        
        if (response.status === 'SUCCESS') {
            handleSignatureSuccess(response);
        } else {
            handleSignatureError(response);
        }
        
    } catch (error) {
        console.error('Erro durante assinatura:', error);
        showError('Erro durante assinatura: ' + error.message);
    } finally {
        hideSigningProgress();
    }
}

/**
 * Mostra progresso da assinatura
 */
function showSigningProgress() {
    elements.signingStatus.classList.remove('hidden');
    elements.signButton.disabled = true;
}

/**
 * Esconde progresso da assinatura
 */
function hideSigningProgress() {
    elements.signingStatus.classList.add('hidden');
    elements.signButton.disabled = false;
}

/**
 * Manipula sucesso na assinatura
 */
function handleSignatureSuccess(response) {
    const data = response.data;
    
    // Armazenar documento assinado
    currentDocument.signedContent = data.signedContent;
    
    // Exibir documento assinado
    elements.signedContent.value = data.signedContent;
    
    // Exibir informações do certificado
    if (data.certificateInfo) {
        displayCertificateInfo(data.certificateInfo);
    }
    
    // Habilitar botões de ação
    elements.downloadButton.classList.remove('hidden');
    elements.copyButton.classList.remove('hidden');
    elements.verifyButton.classList.remove('hidden');
    
    updateStatus('Documento assinado com sucesso!', 'success');
}

/**
 * Manipula erro na assinatura
 */
function handleSignatureError(response) {
    const errorMessage = response.data?.errorMessage || response.message || 'Erro desconhecido';
    showError('Falha na assinatura: ' + errorMessage);
}

/**
 * Exibe informações do certificado
 */
function displayCertificateInfo(certInfo) {
    const details = `
Titular: ${certInfo.subject}
Emissor: ${certInfo.issuer}
Válido de: ${certInfo.validFrom}
Válido até: ${certInfo.validTo}
Número de série: ${certInfo.serialNumber}
    `.trim();
    
    elements.certDetails.textContent = details;
    elements.certInfo.classList.remove('hidden');
}

/**
 * Manipula download do documento assinado
 */
function handleDownloadSigned() {
    if (!currentDocument.signedContent) {
        showError('Nenhum documento assinado disponível');
        return;
    }
    
    const blob = new Blob([currentDocument.signedContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = getSignedFileName(currentDocument.fileName);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    
    URL.revokeObjectURL(url);
    updateStatus('Download iniciado!', 'success');
}

/**
 * Gera nome do arquivo assinado
 */
function getSignedFileName(originalName) {
    const nameWithoutExt = originalName.replace(/\.txt$/i, '');
    const timestamp = new Date().toISOString().slice(0, 19).replace(/[:.]/g, '-');
    return `${nameWithoutExt}_assinado_${timestamp}.txt`;
}

/**
 * Manipula cópia para clipboard
 */
async function handleCopyToClipboard() {
    if (!currentDocument.signedContent) {
        showError('Nenhum documento assinado disponível');
        return;
    }
    
    try {
        await navigator.clipboard.writeText(currentDocument.signedContent);
        updateStatus('Documento copiado para a área de transferência!', 'success');
    } catch (error) {
        console.error('Erro ao copiar:', error);
        // Fallback para browsers mais antigos
        elements.signedContent.select();
        document.execCommand('copy');
        updateStatus('Documento copiado para a área de transferência!', 'success');
    }
}

/**
 * Manipula seleção de arquivo assinado para verificação
 */
function handleSignedFileSelection(event) {
    const file = event.target.files[0];
    
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const signedContent = e.target.result;
        verifySignedDocument(signedContent);
    };
    
    reader.onerror = function() {
        showError('Erro ao ler arquivo assinado');
    };
    
    reader.readAsText(file, 'UTF-8');
}

/**
 * Manipula verificação de assinatura
 */
function handleVerifySignature() {
    if (!currentDocument.signedContent) {
        showError('Nenhum documento assinado disponível para verificação');
        return;
    }
    
    verifySignedDocument(currentDocument.signedContent);
}

/**
 * Verifica um documento assinado
 */
async function verifySignedDocument(signedContent) {
    try {
        updateStatus('Verificando assinatura digital...', 'info');
        
        const request = {
            action: 'VERIFY_SIGNATURE',
            requestId: generateRequestId(),
            data: {
                signedContent: signedContent,
                timestamp: Date.now()
            }
        };
        
        const response = await sendNativeMessage(request);
        
        if (response.status === 'SUCCESS') {
            displayVerificationResult(response.data.verificationInfo);
        } else {
            showError('Erro na verificação: ' + (response.data?.errorMessage || response.message));
        }
        
    } catch (error) {
        console.error('Erro durante verificação:', error);
        showError('Erro durante verificação: ' + error.message);
    }
}

/**
 * Exibe resultado da verificação
 */
function displayVerificationResult(verificationInfo) {
    const resultDiv = elements.verificationResult;
    
    if (verificationInfo.valid) {
        resultDiv.className = 'status success';
        resultDiv.innerHTML = `
            <strong>✅ Assinatura Válida</strong><br>
            ${verificationInfo.message}<br>
            ${verificationInfo.certificateInfo ? '<br><em>Certificado: ' + verificationInfo.certificateInfo + '</em>' : ''}
        `;
        updateStatus('Assinatura verificada com sucesso!', 'success');
    } else {
        resultDiv.className = 'status error';
        resultDiv.innerHTML = `
            <strong>❌ Assinatura Inválida</strong><br>
            ${verificationInfo.message}
        `;
        updateStatus('Assinatura inválida!', 'error');
    }
    
    resultDiv.classList.remove('hidden');
}

/**
 * Envia mensagem para o native host
 */
function sendNativeMessage(message) {
    return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({
            type: 'NATIVE_MESSAGE',
            data: message
        }, (response) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            } else if (response && response.error) {
                reject(new Error(response.error));
            } else {
                resolve(response);
            }
        });
    });
}

/**
 * Gera ID único para requisições
 */
function generateRequestId() {
    return 'req_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

/**
 * Reseta o estado do documento
 */
function resetDocumentState() {
    currentDocument = { content: '', fileName: '', signedContent: '' };
    elements.fileInfo.classList.add('hidden');
    elements.documentContent.value = '';
    elements.signButton.disabled = true;
    elements.signedContent.value = '';
    elements.downloadButton.classList.add('hidden');
    elements.copyButton.classList.add('hidden');
    elements.verifyButton.classList.add('hidden');
    elements.certInfo.classList.add('hidden');
    elements.verificationResult.classList.add('hidden');
}

/**
 * Mostra mensagem de erro
 */
function showError(message) {
    updateStatus(message, 'error');
    console.error('FluxSigner Error:', message);
}

/**
 * Atualiza status geral da aplicação
 */
function updateStatus(message, type = 'info') {
    elements.statusMessage.textContent = message;
    elements.generalStatus.className = `status ${type}`;
    elements.generalStatus.classList.remove('hidden');
    
    // Auto-ocultar mensagens de sucesso após 3 segundos
    if (type === 'success') {
        setTimeout(() => {
            elements.generalStatus.classList.add('hidden');
        }, 3000);
    }
}

