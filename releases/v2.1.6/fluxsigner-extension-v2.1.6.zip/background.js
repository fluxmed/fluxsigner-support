/* 
 * FluxSigner Background Script (v3 - Arquitetura Persistente)
 * 
 * Gerencia uma conexão persistente com o host nativo para maior eficiência
 * e confiabilidade, alinhado com o loop de mensagens do host Java.
 */

const HOST_NAME = 'br.com.fluxsigner.native';
let port = null;

// Fila para mensagens enviadas enquanto a porta está desconectada
let messageQueue = [];

// Mapa para rastrear callbacks de resposta por requestId
let pendingRequests = new Map();

// Timeout para requisições (30 segundos)
const REQUEST_TIMEOUT = 30000;

function connect() {
    console.log("FluxSigner: Tentando conectar ao host nativo...");
    
    try {
        port = chrome.runtime.connectNative(HOST_NAME);
        
        // Log detalhado das mensagens recebidas
        port.onMessage.addListener((response) => {
            console.log("FluxSigner: ===== MENSAGEM RECEBIDA DO HOST NATIVO =====");
            console.log("FluxSigner: Tipo:", typeof response);
            console.log("FluxSigner: Conteúdo:", response);
            console.log("FluxSigner: JSON:", JSON.stringify(response, null, 2));
            onNativeMessage(response);
        });
        
        port.onDisconnect.addListener(onDisconnect);
        
        console.log("FluxSigner: Conexão com o host nativo estabelecida.");
        
        // Processar mensagens que estavam na fila
        if (messageQueue.length > 0) {
            console.log(`FluxSigner: Processando ${messageQueue.length} mensagens da fila...`);
            messageQueue.forEach(item => sendMessageToNativeHost(item.message, item.sendResponse));
            messageQueue = [];
        }
    } catch (error) {
        console.error("FluxSigner: Erro ao conectar ao host nativo:", error);
        handleHostNotInstalled();
    }
}

function onNativeMessage(response) {
    console.log("FluxSigner: Processando resposta do host nativo...");
    
    if (response && response.requestId && pendingRequests.has(response.requestId)) {
        const { sendResponse, timeoutId } = pendingRequests.get(response.requestId);
        
        // Limpar o timeout
        clearTimeout(timeoutId);
        
        // Enviar resposta
        if (response.status === "SUCCESS") {
            console.log("FluxSigner: Resposta SUCCESS para requestId:", response.requestId);
            sendResponse({ status: "SUCCESS", message: response.message || response.data });
        } else {
            console.error("FluxSigner: Resposta ERROR para requestId:", response.requestId);
            sendResponse({ status: "ERROR", message: response.message || "Erro desconhecido no host nativo" });
        }
        
        pendingRequests.delete(response.requestId);
        console.log("FluxSigner: Requisição finalizada. Pendentes restantes:", pendingRequests.size);
    } else {
        console.warn("FluxSigner: Resposta recebida sem requestId correspondente:", response);
        console.warn("FluxSigner: RequestId na resposta:", response?.requestId);
        console.warn("FluxSigner: Requisições pendentes:", Array.from(pendingRequests.keys()));
    }
}

function onDisconnect() {
    console.warn("FluxSigner: Porta do host nativo desconectada.");
    
    if (chrome.runtime.lastError) {
        const errorMsg = chrome.runtime.lastError.message;
        console.error("FluxSigner: Erro de desconexão:", errorMsg);
        
        // Verificar se é erro de host não encontrado
        if (errorMsg.includes("Specified native messaging host not found") ||
            errorMsg.includes("Native host has exited")) {
            handleHostNotInstalled();
            return;
        }
    }
    
    // Limpar requisições pendentes com erro genérico
    pendingRequests.forEach(({ sendResponse, timeoutId }) => {
        clearTimeout(timeoutId);
        sendResponse({ 
            status: "ERROR", 
            message: "Erro na comunicação: O host nativo foi desconectado." 
        });
    });

    port = null;
    pendingRequests.clear();
}

/**
 * Trata o caso quando o Native Host não está instalado
 */
function handleHostNotInstalled() {
    console.error("FluxSigner: Native Host não está instalado!");
    
    // Rejeitar todas as mensagens pendentes na fila
    messageQueue.forEach(item => {
        item.sendResponse({
            status: "ERROR",
            message: "HOST_NOT_INSTALLED",
            downloadUrl: "https://github.com/fluxmed/fluxsigner-support/releases/latest"
        });
    });
    messageQueue = [];
    
    // Rejeitar requisições pendentes
    pendingRequests.forEach(({ sendResponse, timeoutId }) => {
        clearTimeout(timeoutId);
        sendResponse({
            status: "ERROR",
            message: "HOST_NOT_INSTALLED",
            downloadUrl: "https://github.com/fluxmed/fluxsigner-support/releases/latest"
        });
    });
    pendingRequests.clear();
}

function sendMessageToNativeHost(message, sendResponse) {
    if (!port) {
        console.log("FluxSigner: Porta não conectada. Enfileirando mensagem e tentando reconectar.");
        messageQueue.push({ message, sendResponse });
        connect();
        return;
    }

    const requestId = generateRequestId();
    
    // Configurar timeout para a requisição
    const timeoutId = setTimeout(() => {
        if (pendingRequests.has(requestId)) {
            console.warn("FluxSigner: Timeout na requisição:", requestId);
            pendingRequests.delete(requestId);
            sendResponse({ 
                status: "ERROR", 
                message: "Timeout: O host nativo não respondeu em tempo hábil." 
            });
        }
    }, REQUEST_TIMEOUT);
    
    // Armazenar callback junto com o timeout ID
    pendingRequests.set(requestId, { sendResponse, timeoutId });

    const nativeRequest = {
        action: message.action,
        requestId: requestId,
        data: message.data || null
    };

    console.log("FluxSigner: ===== ENVIANDO MENSAGEM PARA HOST NATIVO =====");
    console.log("FluxSigner: Action:", nativeRequest.action);
    console.log("FluxSigner: RequestId:", nativeRequest.requestId);
    console.log("FluxSigner: Requisições pendentes:", pendingRequests.size);
    
    try {
        port.postMessage(nativeRequest);
        console.log("FluxSigner: Mensagem enviada com sucesso.");
    } catch (error) {
        console.error("FluxSigner: Erro ao enviar mensagem:", error);
        clearTimeout(timeoutId);
        pendingRequests.delete(requestId);
        sendResponse({ status: "ERROR", message: "Erro ao enviar mensagem: " + error.message });
    }
}

function handleIncomingMessage(message, sender, sendResponse) {
    console.info("FluxSigner: Mensagem recebida:", message.action, "de:", sender.id || sender.url);
    
    // Tratamento especial para PING para não depender da conexão nativa
    if (message.action === 'PING') {
        sendResponse({ status: 'SUCCESS', message: 'PONG - FluxSigner v2.1.5 está funcionando!' });
        return true; // Retornar true para indicar resposta assíncrona
    }

    // Para outras ações, garantir que a porta esteja conectada
    if (!port) {
        connect();
    }

    sendMessageToNativeHost(message, sendResponse);
    return true; // Manter canal de resposta aberto para operações assíncronas
}

// Listeners para mensagens internas e externas
chrome.runtime.onMessage.addListener(handleIncomingMessage);
chrome.runtime.onMessageExternal.addListener(handleIncomingMessage);

function generateRequestId() {
    return 'req_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

console.log("FluxSigner: Service Worker (v3 - persistente) iniciado.");
