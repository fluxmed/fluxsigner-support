/* content.js - Melhorado para Manifest V3 */

/**
 * Verifica se a extensão ainda está ativa
 */
function isExtensionActive() {
	return chrome.runtime && chrome.runtime.id;
}

/**
 * Event listener para enviar mensagens ao background script
 * Cliente dispara evento 'send-message-event' com dados
 */
document.addEventListener("send-message-event", function (data) {
	try {
		if (!isExtensionActive()) {
			console.error("Extensão foi descarregada. Recarregue a página.");
			alert("Extensão foi descarregada. Por favor, recarregue a página (F5).");
			return;
		}

		const request = data.detail.data;
		console.info("Enviando mensagem para background:", request);
		
		// Enviar mensagem para o background script
		chrome.runtime.sendMessage(request, (response) => {
			if (chrome.runtime.lastError) {
				console.error("Erro ao enviar mensagem:", chrome.runtime.lastError.message);
			}
		});
	} catch (error) {
		console.error("Erro no content script:", error);
		alert("Erro na extensão. Recarregue a página (F5) e tente novamente.");
	}
});

/**
 * Escuta mensagens do background script e envia para a página
 */
chrome.runtime.onMessage.addListener(function (response, sender, sendResponse) {
	try {
		console.info("Resposta recebida do background:", response);
		
		// Enviar resposta para a página web
		const event = new CustomEvent("get-message-event", {
			detail: {
				data: response
			},
			bubbles: true,
			cancelable: true
		});
		document.dispatchEvent(event);
		
		// Confirmar recebimento
		sendResponse({received: true});
	} catch (error) {
		console.error("Erro ao processar resposta:", error);
	}
});

// Log de inicialização
console.info("Content script carregado - Native Messaging Extension");