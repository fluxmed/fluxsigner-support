/**
 * FluxSigner Certificate Manager
 * Sistema de gerenciamento de certificados A1 ICP-Brasil
 */

class CertificateManager {
    constructor() {
        // Estado da aplicação
        this.currentFile = null;
        this.certificates = [];
        this.selectedCertificate = null;
        this.isProcessing = false;
        
        // Elementos DOM
        this.elements = {};
        
        // Configurações
        this.config = {
            maxFileSize: 10 * 1024 * 1024, // 10MB
            validExtensions: ['.pfx', '.p12'],
            toastDuration: 5000,
            logMaxEntries: 100
        };
        
        this.init();
    }
    
    /**
     * Inicializa o gerenciador
     */
    async init() {
        try {
            this.initializeElements();
            this.setupEventListeners();
            this.log('🚀 Gerenciador de certificados inicializado', 'success');
            
            // Carregar certificados existentes
            await this.loadCertificates();
            
        } catch (error) {
            this.log(`❌ Erro na inicialização: ${error.message}`, 'error');
            this.showToast('Erro ao inicializar o sistema', 'error');
        }
    }
    
    /**
     * Inicializa referências dos elementos DOM
     */
    initializeElements() {
        // Upload elements
        this.elements.uploadArea = document.getElementById('uploadArea');
        this.elements.uploadLink = document.getElementById('uploadLink');
        this.elements.fileInput = document.getElementById('fileInput');
        this.elements.uploadForm = document.getElementById('uploadForm');
        this.elements.uploadStatus = document.getElementById('uploadStatus');
        
        // Form elements
        this.elements.certificateAlias = document.getElementById('certificateAlias');
        this.elements.certificatePassword = document.getElementById('certificatePassword');
        this.elements.replaceIfExists = document.getElementById('replaceIfExists');
        
        // Action buttons
        this.elements.cancelUpload = document.getElementById('cancelUpload');
        this.elements.installCertificate = document.getElementById('installCertificate');
        
        // Progress elements
        this.elements.progressFill = document.getElementById('progressFill');
        this.elements.progressText = document.getElementById('progressText');
        this.elements.statusText = document.getElementById('statusText');
        
        // Certificate list elements
        this.elements.refreshCertificates = document.getElementById('refreshCertificates');
        this.elements.searchCertificates = document.getElementById('searchCertificates');
        this.elements.certificatesList = document.getElementById('certificatesList');
        this.elements.certificatesStats = document.getElementById('certificatesStats');
        
        // Details elements
        this.elements.detailsSection = document.getElementById('detailsSection');
        this.elements.certificateDetails = document.getElementById('certificateDetails');
        
        // Detail action buttons
        this.elements.testCertificate = document.getElementById('testCertificate');
        this.elements.exportCertificate = document.getElementById('exportCertificate');
        this.elements.removeCertificate = document.getElementById('removeCertificate');
        
        // Modal elements
        this.elements.confirmModal = document.getElementById('confirmModal');
        this.elements.confirmTitle = document.getElementById('confirmTitle');
        this.elements.confirmMessage = document.getElementById('confirmMessage');
        this.elements.confirmCancel = document.getElementById('confirmCancel');
        this.elements.confirmOk = document.getElementById('confirmOk');
        this.elements.modalClose = document.getElementById('modalClose');
        
        // Log elements
        this.elements.logContainer = document.getElementById('logContainer');
        this.elements.clearLog = document.getElementById('clearLog');
        this.elements.exportLog = document.getElementById('exportLog');
        
        // Toast container
        this.elements.toastContainer = document.getElementById('toastContainer');
        
        this.log('📋 Elementos DOM inicializados');
    }
    
    /**
     * Configura event listeners
     */
    setupEventListeners() {
        // Upload events
        this.elements.uploadArea.addEventListener('dragover', (e) => this.handleDragOver(e));
        this.elements.uploadArea.addEventListener('dragleave', (e) => this.handleDragLeave(e));
        this.elements.uploadArea.addEventListener('drop', (e) => this.handleDrop(e));
        this.elements.uploadLink.addEventListener('click', () => this.elements.fileInput.click());
        this.elements.fileInput.addEventListener('change', (e) => this.handleFileSelect(e));
        
        // Form events
        this.elements.cancelUpload.addEventListener('click', () => this.cancelUpload());
        this.elements.installCertificate.addEventListener('click', () => this.installCertificate());
        
        // Certificate management events
        this.elements.refreshCertificates.addEventListener('click', () => this.loadCertificates());
        this.elements.searchCertificates.addEventListener('input', (e) => this.filterCertificates(e.target.value));
        
        // Detail actions
        this.elements.testCertificate.addEventListener('click', () => this.testCertificate());
        this.elements.exportCertificate.addEventListener('click', () => this.exportCertificate());
        this.elements.removeCertificate.addEventListener('click', () => this.removeCertificate());
        
        // Modal events
        this.elements.confirmCancel.addEventListener('click', () => this.hideModal());
        this.elements.confirmOk.addEventListener('click', () => this.confirmAction());
        this.elements.modalClose.addEventListener('click', () => this.hideModal());
        this.elements.confirmModal.addEventListener('click', (e) => {
            if (e.target === this.elements.confirmModal) this.hideModal();
        });
        
        // Log events
        this.elements.clearLog.addEventListener('click', () => this.clearLog());
        this.elements.exportLog.addEventListener('click', () => this.exportLog());
        
        // Form validation
        this.elements.certificateAlias.addEventListener('input', () => this.validateForm());
        this.elements.certificatePassword.addEventListener('input', () => this.validateForm());
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => this.handleKeyboard(e));
        
        this.log('🔗 Event listeners configurados');
    }
    
    // ========== DRAG & DROP ==========
    
    handleDragOver(e) {
        e.preventDefault();
        e.stopPropagation();
        this.elements.uploadArea.classList.add('drag-over');
    }
    
    handleDragLeave(e) {
        e.preventDefault();
        e.stopPropagation();
        this.elements.uploadArea.classList.remove('drag-over');
    }
    
    handleDrop(e) {
        e.preventDefault();
        e.stopPropagation();
        this.elements.uploadArea.classList.remove('drag-over');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            this.processFile(files[0]);
        }
    }
    
    handleFileSelect(e) {
        const files = e.target.files;
        if (files.length > 0) {
            this.processFile(files[0]);
        }
    }
    
    // ========== FILE PROCESSING ==========
    
    processFile(file) {
        this.log(`📁 Arquivo selecionado: ${file.name} (${this.formatFileSize(file.size)})`);
        
        // Validar tipo de arquivo
        const isValidType = this.config.validExtensions.some(ext => 
            file.name.toLowerCase().endsWith(ext));
        
        if (!isValidType) {
            this.showToast('Arquivo inválido. Selecione um arquivo .pfx ou .p12', 'error');
            this.log('❌ Tipo de arquivo inválido', 'error');
            return;
        }
        
        // Validar tamanho
        if (file.size > this.config.maxFileSize) {
            this.showToast(`Arquivo muito grande. Tamanho máximo: ${this.formatFileSize(this.config.maxFileSize)}`, 'error');
            this.log('❌ Arquivo muito grande', 'error');
            return;
        }
        
        this.currentFile = file;
        this.showUploadForm(file);
    }
    
    showUploadForm(file) {
        // Ocultar área de upload
        this.elements.uploadArea.style.display = 'none';
        
        // Mostrar formulário
        this.elements.uploadForm.style.display = 'block';
        
        // Preencher nome sugerido (sem extensão)
        const suggestedName = file.name.replace(/\.(pfx|p12)$/i, '');
        this.elements.certificateAlias.value = suggestedName;
        
        // Focar no campo de senha
        this.elements.certificatePassword.focus();
        
        this.validateForm();
        this.log(`📝 Formulário exibido para: ${file.name}`);
    }
    
    // ========== FORM HANDLING ==========
    
    validateForm() {
        const alias = this.elements.certificateAlias.value.trim();
        const password = this.elements.certificatePassword.value;
        
        const isValid = alias.length >= 3 && password.length >= 4;
        this.elements.installCertificate.disabled = !isValid || this.isProcessing;
        
        return isValid;
    }
    
    cancelUpload() {
        this.currentFile = null;
        this.elements.uploadForm.style.display = 'none';
        this.elements.uploadArea.style.display = 'block';
        this.elements.uploadStatus.style.display = 'none';
        
        // Limpar formulário
        this.elements.certificateAlias.value = '';
        this.elements.certificatePassword.value = '';
        this.elements.replaceIfExists.checked = false;
        this.elements.fileInput.value = '';
        
        this.log('🚫 Upload cancelado');
    }
    
    async installCertificate() {
        if (!this.currentFile || !this.validateForm() || this.isProcessing) {
            return;
        }
        
        const alias = this.elements.certificateAlias.value.trim();
        const password = this.elements.certificatePassword.value;
        const replaceIfExists = this.elements.replaceIfExists.checked;
        
        this.isProcessing = true;
        this.elements.installCertificate.classList.add('loading');
        
        try {
            this.log(`⚡ Iniciando instalação: ${alias}`);
            
            // Mostrar progresso
            this.showProgress('Preparando instalação...', 10);
            
            // Converter arquivo para base64
            this.showProgress('Lendo arquivo...', 30);
            const fileData = await this.fileToBase64(this.currentFile);
            
            // Enviar para native host
            this.showProgress('Validando certificado...', 50);
            const response = await this.sendMessage('INSTALL_CERTIFICATE', {
                fileName: this.currentFile.name,
                fileData: fileData,
                password: password,
                alias: alias,
                replaceIfExists: replaceIfExists
            });
            
            this.showProgress('Finalizando instalação...', 90);
            
            if (response.success) {
                this.showProgress('Certificado instalado com sucesso!', 100);
                this.log(`✅ Certificado "${alias}" instalado com sucesso`);
                this.showToast(`Certificado "${alias}" instalado com sucesso!`, 'success');
                
                // Aguardar um pouco e resetar interface
                setTimeout(() => {
                    this.cancelUpload();
                    this.loadCertificates();
                }, 2000);
                
            } else {
                throw new Error(response.errorMessage || 'Erro desconhecido na instalação');
            }
            
        } catch (error) {
            this.log(`❌ Erro na instalação: ${error.message}`, 'error');
            this.showToast(`Erro na instalação: ${error.message}`, 'error');
            this.elements.uploadStatus.style.display = 'none';
        } finally {
            this.isProcessing = false;
            this.elements.installCertificate.classList.remove('loading');
        }
    }
    
    showProgress(message, percentage) {
        this.elements.uploadStatus.style.display = 'block';
        this.elements.statusText.textContent = message;
        this.elements.progressFill.style.width = percentage + '%';
        this.elements.progressText.textContent = percentage + '%';
    }
    
    // ========== CERTIFICATE MANAGEMENT ==========
    
    async loadCertificates() {
        try {
            this.elements.certificatesList.innerHTML = '<div class="loading"><div class="loading-spinner"></div><span>Carregando certificados...</span></div>';
            
            this.log('📋 Carregando lista de certificados...');
            
            const response = await this.sendMessage('GET_ALL_CERTIFICATES', { forceRefresh: false });
            
            if (response.success && response.data) {
                // Parse da resposta
                const data = typeof response.data === 'string' ? JSON.parse(response.data) : response.data;
                this.certificates = data.certificates || [];
                
                this.renderCertificatesList();
                this.updateCertificatesStats();
                this.log(`📋 ${this.certificates.length} certificado(s) carregado(s)`);
                
            } else {
                throw new Error(response.errorMessage || 'Erro ao carregar certificados');
            }
            
        } catch (error) {
            this.log(`❌ Erro ao carregar certificados: ${error.message}`, 'error');
            this.elements.certificatesList.innerHTML = '<div class="error">Erro ao carregar certificados</div>';
            this.showToast('Erro ao carregar certificados', 'error');
        }
    }
    
    renderCertificatesList() {
        if (this.certificates.length === 0) {
            this.elements.certificatesList.innerHTML = '<div class="empty">Nenhum certificado instalado</div>';
            return;
        }
        
        const html = this.certificates.map(cert => this.renderCertificateItem(cert)).join('');
        this.elements.certificatesList.innerHTML = html;
        
        // Adicionar event listeners
        this.elements.certificatesList.querySelectorAll('.certificate-item').forEach(item => {
            item.addEventListener('click', () => {
                const certId = item.dataset.certificateId;
                this.selectCertificate(certId);
            });
        });
    }
    
    renderCertificateItem(cert) {
        // Usar certificateInfo se disponível, caso contrário campos diretos (compatibilidade)
        const certInfo = cert.certificateInfo || cert;
        const notAfter = certInfo.notAfter || cert.notAfter;
        const subject = certInfo.subject || cert.subject;
        
        const isExpired = new Date(notAfter) < new Date();
        const isExpiringSoon = this.isExpiringSoon(notAfter, 30);
        
        let statusClass = 'valid';
        let statusIcon = '✅';
        let statusText = 'Válido';
        
        if (isExpired) {
            statusClass = 'expired';
            statusIcon = '❌';
            statusText = 'Expirado';
        } else if (isExpiringSoon) {
            statusClass = 'expiring';
            statusIcon = '⚠️';
            statusText = 'Expirando';
        }
        
        const icpIcon = cert.icpBrasilCompliant ? '🇧🇷' : '⚪';
        
        // Determinar ícone baseado na fonte
        let typeIcon = '💾'; // Default A1
        if (cert.source === 'WINDOWS_STORE') {
            typeIcon = '🪟';
        } else if (cert.source === 'PKCS11_TOKEN') {
            typeIcon = '🔐';
        } else if (cert.source === 'MANUAL_UPLOAD') {
            typeIcon = '📤';
        }
        
        // Nome amigável
        const displayName = cert.friendlyName || cert.alias || 'Certificado';
        
        return `
            <div class="certificate-item ${statusClass}" data-certificate-id="${cert.alias}">
                <div class="cert-icon">${typeIcon}</div>
                <div class="cert-info">
                    <div class="cert-name">${this.escapeHtml(displayName)}</div>
                    <div class="cert-subject">${this.extractCN(subject)}</div>
                    <div class="cert-details">
                        <span class="cert-source">${cert.sourceDisplayName || cert.source || 'Desconhecido'}</span>
                        <span class="cert-icp">${icpIcon} ${cert.icpBrasilCompliant ? 'ICP-Brasil' : 'Não ICP'}</span>
                        <span class="cert-expiry">Válido até ${this.formatDate(notAfter)}</span>
                    </div>
                </div>
                <div class="cert-status ${statusClass}">
                    <div class="status-icon">${statusIcon}</div>
                    <div class="status-text">${statusText}</div>
                </div>
            </div>
        `;
    }
    
    selectCertificate(certificateId) {
        // Remover seleção anterior
        this.elements.certificatesList.querySelectorAll('.certificate-item').forEach(item => {
            item.classList.remove('selected');
        });
        
        // Adicionar seleção atual
        const selectedItem = this.elements.certificatesList.querySelector(
            `[data-certificate-id="${certificateId}"]`);
        if (selectedItem) {
            selectedItem.classList.add('selected');
        }
        
        // Encontrar certificado
        this.selectedCertificate = this.certificates.find(cert => cert.alias === certificateId);
        
        if (this.selectedCertificate) {
            this.showCertificateDetails(this.selectedCertificate);
            this.log(`🔍 Certificado selecionado: ${this.selectedCertificate.alias}`);
        }
    }
    
    showCertificateDetails(cert) {
        // Usar certificateInfo se disponível, caso contrário campos diretos (compatibilidade)
        const certInfo = cert.certificateInfo || cert;
        const notAfter = certInfo.notAfter || cert.notAfter;
        const subject = certInfo.subject || cert.subject;
        const issuer = certInfo.issuer || cert.issuer;
        
        const isExpired = new Date(notAfter) < new Date();
        const daysUntilExpiry = Math.ceil((new Date(notAfter) - new Date()) / (1000 * 60 * 60 * 24));
        
        const displayName = cert.friendlyName || cert.alias || 'Certificado';
        const sourceIcon = cert.source === 'WINDOWS_STORE' ? '🪟' : cert.source === 'PKCS11_TOKEN' ? '🔐' : '📤';
        
        const detailsHtml = `
            <div class="cert-detail-header">
                <h3>${this.escapeHtml(displayName)}</h3>
                <div class="cert-badges">
                    <span class="badge source">${sourceIcon} ${cert.sourceDisplayName || cert.source || 'Desconhecido'}</span>
                    <span class="badge ${cert.icpBrasilCompliant ? 'icp' : 'non-icp'}">
                        ${cert.icpBrasilCompliant ? '🇧🇷 ICP-Brasil' : '⚪ Não ICP'}
                    </span>
                    ${isExpired ? '<span class="badge expired">❌ Expirado</span>' : 
                      daysUntilExpiry <= 30 ? '<span class="badge expiring">⚠️ Expirando</span>' : 
                      '<span class="badge valid">✅ Válido</span>'}
                </div>
            </div>
            
            <div class="cert-detail-grid">
                <div class="detail-group">
                    <h4>👤 Informações do Titular</h4>
                    <div class="detail-item">
                        <span class="label">Nome:</span>
                        <span class="value">${this.extractCN(subject)}</span>
                    </div>
                    ${cert.icpValidation && cert.icpValidation.cpfCnpj ? `
                        <div class="detail-item">
                            <span class="label">CPF/CNPJ:</span>
                            <span class="value">${this.formatCpfCnpj(cert.icpValidation.cpfCnpj)}</span>
                        </div>
                    ` : ''}
                    <div class="detail-item">
                        <span class="label">Assunto:</span>
                        <span class="value small">${this.escapeHtml(subject)}</span>
                    </div>
                </div>
                
                <div class="detail-group">
                    <h4>🏛️ Autoridade Certificadora</h4>
                    <div class="detail-item">
                        <span class="label">Emissor:</span>
                        <span class="value">${this.extractCN(issuer)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Número de Série:</span>
                        <span class="value small">${certInfo.serialNumber || 'N/A'}</span>
                    </div>
                </div>
                
                <div class="detail-group">
                    <h4>📅 Validade</h4>
                    <div class="detail-item">
                        <span class="label">Válido de:</span>
                        <span class="value">${this.formatDateTime(certInfo.notBefore || cert.notBefore)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Válido até:</span>
                        <span class="value">${this.formatDateTime(notAfter)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Status:</span>
                        <span class="value ${isExpired ? 'expired' : daysUntilExpiry <= 30 ? 'expiring' : 'valid'}">
                            ${isExpired ? '❌ Expirado' : 
                              daysUntilExpiry <= 30 ? `⚠️ Expira em ${daysUntilExpiry} dias` : 
                              '✅ Válido'}
                        </span>
                    </div>
                </div>
                
                <div class="detail-group">
                    <h4>📊 Informações de Uso</h4>
                    <div class="detail-item">
                        <span class="label">Instalado em:</span>
                        <span class="value">${this.formatDateTime(cert.installationDate)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Último uso:</span>
                        <span class="value">${cert.lastUsed ? this.formatDateTime(cert.lastUsed) : 'Nunca usado'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Vezes usado:</span>
                        <span class="value">${cert.usageCount}</span>
                    </div>
                </div>
            </div>
        `;
        
        this.elements.certificateDetails.innerHTML = detailsHtml;
        this.elements.detailsSection.style.display = 'block';
        
        // Habilitar/desabilitar botões baseado no status
        this.elements.testCertificate.disabled = isExpired;
        this.elements.exportCertificate.disabled = false;
        this.elements.removeCertificate.disabled = false;
    }
    
    updateCertificatesStats() {
        const total = this.certificates.length;
        const valid = this.certificates.filter(cert => !this.isExpired(cert)).length;
        const expiring = this.certificates.filter(cert => 
            !this.isExpired(cert) && this.isExpiringSoon(cert.notAfter, 30)).length;
        
        this.elements.certificatesStats.innerHTML = `
            <span class="stats-item">Total: <strong>${total}</strong></span>
            <span class="stats-item">Válidos: <strong>${valid}</strong></span>
            <span class="stats-item">Expirando: <strong>${expiring}</strong></span>
        `;
    }
    
    filterCertificates(searchTerm) {
        const items = this.elements.certificatesList.querySelectorAll('.certificate-item');
        const term = searchTerm.toLowerCase();
        
        items.forEach(item => {
            const text = item.textContent.toLowerCase();
            const matches = text.includes(term);
            item.style.display = matches ? 'flex' : 'none';
        });
        
        this.log(`🔍 Filtro aplicado: "${searchTerm}"`);
    }
    
    // ========== CERTIFICATE ACTIONS ==========
    
    async testCertificate() {
        if (!this.selectedCertificate) return;
        
        try {
            this.log(`🧪 Testando certificado: ${this.selectedCertificate.alias}`);
            this.elements.testCertificate.disabled = true;
            
            const response = await this.sendMessage('TEST_CERTIFICATE', {
                certificateId: this.selectedCertificate.certificateId
            });
            
            if (response.success) {
                const result = typeof response.data === 'string' ? JSON.parse(response.data) : response.data;
                
                if (result.success) {
                    this.log(`✅ Teste bem-sucedido: ${result.message}`);
                    this.showToast('Certificado testado com sucesso!', 'success');
                } else {
                    this.log(`❌ Teste falhou: ${result.message}`, 'error');
                    this.showToast(`Teste falhou: ${result.message}`, 'error');
                }
            } else {
                throw new Error(response.errorMessage);
            }
            
        } catch (error) {
            this.log(`❌ Erro no teste: ${error.message}`, 'error');
            this.showToast(`Erro no teste: ${error.message}`, 'error');
        } finally {
            this.elements.testCertificate.disabled = false;
        }
    }
    
    async exportCertificate() {
        if (!this.selectedCertificate) return;
        
        try {
            this.log(`📤 Exportando certificado: ${this.selectedCertificate.alias}`);
            this.elements.exportCertificate.disabled = true;
            
            const response = await this.sendMessage('EXPORT_CERTIFICATE', {
                certificateId: this.selectedCertificate.certificateId
            });
            
            if (response.success) {
                const result = typeof response.data === 'string' ? JSON.parse(response.data) : response.data;
                
                if (result.success) {
                    // Criar download do certificado público
                    const certData = result.certificateData;
                    const blob = new Blob([atob(certData)], { type: 'application/x-x509-ca-cert' });
                    const url = URL.createObjectURL(blob);
                    
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `${this.selectedCertificate.alias}.crt`;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                    
                    this.log(`✅ Certificado exportado: ${this.selectedCertificate.alias}.crt`);
                    this.showToast('Certificado exportado com sucesso!', 'success');
                } else {
                    throw new Error(result.errorMessage);
                }
            } else {
                throw new Error(response.errorMessage);
            }
            
        } catch (error) {
            this.log(`❌ Erro na exportação: ${error.message}`, 'error');
            this.showToast(`Erro na exportação: ${error.message}`, 'error');
        } finally {
            this.elements.exportCertificate.disabled = false;
        }
    }
    
    removeCertificate() {
        if (!this.selectedCertificate) return;
        
        this.showModal(
            '🗑️ Remover Certificado',
            `Tem certeza que deseja remover o certificado "${this.selectedCertificate.alias}"?\n\nEsta ação não pode ser desfeita.`,
            async () => {
                try {
                    this.log(`🗑️ Removendo certificado: ${this.selectedCertificate.alias}`);
                    
                    const response = await this.sendMessage('REMOVE_CERTIFICATE', {
                        certificateId: this.selectedCertificate.certificateId
                    });
                    
                    if (response.success) {
                        const result = typeof response.data === 'string' ? JSON.parse(response.data) : response.data;
                        
                        if (result.success) {
                            this.log(`✅ Certificado removido: ${this.selectedCertificate.alias}`);
                            this.showToast('Certificado removido com sucesso!', 'success');
                            
                            // Atualizar lista
                            this.loadCertificates();
                            this.elements.detailsSection.style.display = 'none';
                            this.selectedCertificate = null;
                        } else {
                            throw new Error(result.errorMessage);
                        }
                    } else {
                        throw new Error(response.errorMessage);
                    }
                    
                } catch (error) {
                    this.log(`❌ Erro na remoção: ${error.message}`, 'error');
                    this.showToast(`Erro na remoção: ${error.message}`, 'error');
                }
            }
        );
    }
    
    // ========== MODAL ==========
    
    showModal(title, message, onConfirm) {
        this.elements.confirmTitle.textContent = title;
        this.elements.confirmMessage.textContent = message;
        this.elements.confirmModal.style.display = 'flex';
        
        this.pendingConfirmAction = onConfirm;
    }
    
    hideModal() {
        this.elements.confirmModal.style.display = 'none';
        this.pendingConfirmAction = null;
    }
    
    confirmAction() {
        if (this.pendingConfirmAction) {
            this.pendingConfirmAction();
        }
        this.hideModal();
    }
    
    // ========== COMMUNICATION ==========
    
    async sendMessage(action, data = null) {
        return new Promise((resolve, reject) => {
            const message = {
                action: action,
                data: data ? JSON.stringify(data) : null,
                requestId: this.generateRequestId()
            };
            
            chrome.runtime.sendMessage(message, (response) => {
                if (chrome.runtime.lastError) {
                    // Se for erro de "Native host has exited", tratar silenciosamente
                    if (chrome.runtime.lastError.message.includes('Native host has exited')) {
                        console.warn('Native Host finalizou inesperadamente, mas operação pode ter sido concluída');
                        // Retornar resposta padrão para evitar erro visual
                        resolve({
                            success: false,
                            data: null,
                            errorMessage: 'Native Host finalizou inesperadamente'
                        });
                        return;
                    }
                    // Outros erros são tratados normalmente
                    reject(new Error(chrome.runtime.lastError.message));
                } else if (response && response.status) {
                    // Converter formato do background.js para o esperado
                    if (response.status === 'SUCCESS') {
                        resolve({
                            success: true,
                            data: response.message,
                            errorMessage: null
                        });
                    } else {
                        resolve({
                            success: false,
                            data: null,
                            errorMessage: response.message || 'Erro desconhecido'
                        });
                    }
                } else {
                    reject(new Error('Resposta inválida do sistema'));
                }
            });
        });
    }
    
    generateRequestId() {
        return 'cert_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
    
    // ========== UTILITIES ==========
    
    async fileToBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                const base64 = reader.result.split(',')[1];
                resolve(base64);
            };
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }
    
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    formatDate(dateString) {
        return new Date(dateString).toLocaleDateString('pt-BR');
    }
    
    formatDateTime(dateString) {
        return new Date(dateString).toLocaleString('pt-BR');
    }
    
    formatCpfCnpj(cpfCnpj) {
        if (!cpfCnpj) return '';
        
        const numbers = cpfCnpj.replace(/\D/g, '');
        
        if (numbers.length === 11) {
            return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
        } else if (numbers.length === 14) {
            return numbers.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
        }
        
        return cpfCnpj;
    }
    
    extractCN(dn) {
        if (!dn) return '';
        const match = dn.match(/CN=([^,]+)/);
        return match ? match[1].trim() : dn;
    }
    
    isExpiringSoon(dateString, days) {
        const expiryDate = new Date(dateString);
        const now = new Date();
        const daysUntilExpiry = Math.ceil((expiryDate - now) / (1000 * 60 * 60 * 24));
        return daysUntilExpiry <= days && daysUntilExpiry >= 0;
    }
    
    isExpired(cert) {
        return new Date(cert.notAfter) < new Date();
    }
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    // ========== TOAST NOTIFICATIONS ==========
    
    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        const icons = {
            success: '✅',
            error: '❌',
            warning: '⚠️',
            info: 'ℹ️'
        };
        
        toast.innerHTML = `
            <div class="toast-icon">${icons[type] || icons.info}</div>
            <div class="toast-message">${this.escapeHtml(message)}</div>
            <button class="toast-close">×</button>
        `;
        
        // Event listener para fechar
        toast.querySelector('.toast-close').addEventListener('click', () => {
            toast.remove();
        });
        
        // Adicionar ao container
        this.elements.toastContainer.appendChild(toast);
        
        // Auto-remover após duração configurada
        setTimeout(() => {
            if (toast.parentNode) {
                toast.style.opacity = '0';
                setTimeout(() => toast.remove(), 300);
            }
        }, this.config.toastDuration);
    }
    
    // ========== LOGGING ==========
    
    log(message, type = 'info') {
        const timestamp = new Date().toLocaleTimeString('pt-BR');
        const logEntry = document.createElement('div');
        logEntry.className = `log-entry`;
        
        const typeIcons = {
            success: '✅',
            error: '❌',
            warning: '⚠️',
            info: 'ℹ️'
        };
        
        logEntry.innerHTML = `
            <span class="log-time">[${timestamp}]</span>
            <span class="log-message ${type}">${typeIcons[type] || ''} ${this.escapeHtml(message)}</span>
        `;
        
        this.elements.logContainer.appendChild(logEntry);
        this.elements.logContainer.scrollTop = this.elements.logContainer.scrollHeight;
        
        // Limitar número de entradas
        const entries = this.elements.logContainer.querySelectorAll('.log-entry');
        if (entries.length > this.config.logMaxEntries) {
            entries[0].remove();
        }
        
        // Console log para desenvolvimento
        console.log(`[FluxSigner] ${message}`, type);
    }
    
    clearLog() {
        this.elements.logContainer.innerHTML = '';
        this.log('🧹 Log limpo');
    }
    
    exportLog() {
        const entries = Array.from(this.elements.logContainer.querySelectorAll('.log-entry'));
        const logText = entries.map(entry => entry.textContent).join('\n');
        
        const blob = new Blob([logText], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `fluxsigner-log-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        this.log('💾 Log exportado');
    }
    
    // ========== KEYBOARD SHORTCUTS ==========
    
    handleKeyboard(e) {
        // ESC para fechar modal
        if (e.key === 'Escape' && this.elements.confirmModal.style.display === 'flex') {
            this.hideModal();
        }
        
        // Ctrl+R para atualizar certificados
        if (e.ctrlKey && e.key === 'r' && !e.defaultPrevented) {
            e.preventDefault();
            this.loadCertificates();
        }
        
        // Ctrl+L para limpar log
        if (e.ctrlKey && e.key === 'l' && !e.defaultPrevented) {
            e.preventDefault();
            this.clearLog();
        }
    }
}

// Inicializar quando a página carregar
document.addEventListener('DOMContentLoaded', () => {
    new CertificateManager();
});
