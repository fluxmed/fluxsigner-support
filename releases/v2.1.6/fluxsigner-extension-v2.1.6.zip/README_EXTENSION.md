# FluxSigner - Extensão para Chrome/Edge

## ⚠️ **INSTALAÇÃO OBRIGATÓRIA DO NATIVE HOST**

**ATENÇÃO:** Esta extensão NÃO funciona sozinha!

### 📥 **ANTES de usar esta extensão, você DEVE:**

1. **Baixar e instalar o Native Host:**
   
   👉 **https://github.com/fluxmed/fluxsigner-support/releases/latest**
   
   - Baixe: `FluxSignerSetup.exe`
   - Execute o instalador
   - Siga as instruções

2. **Depois, instale esta extensão**

---

## 🎯 O que é o FluxSigner?

O FluxSigner é uma extensão de navegador que permite assinar documentos PDF digitalmente usando certificados ICP-Brasil diretamente do Chrome ou Edge. Com total segurança e privacidade - todo processamento acontece localmente em seu computador.

## ✨ Características

- ✅ **Assinatura Digital PAdES** com validade jurídica
- ✅ **Timestamp confiável (TSA)** aplicado automaticamente
- ✅ **Certificados ICP-Brasil** A1, A3 e A4
- ✅ **Download automático** de PDFs assinados
- ✅ **Interface profissional** e minimalista
- ✅ **Privacidade total** - tudo processado localmente

## ⚙️ Requisitos

- **Windows 10 ou superior**
- **Java 11 ou superior** (instalado automaticamente pelo instalador)
- **Certificado Digital ICP-Brasil** (A1 ou A3)
- **Native Host FluxSigner** instalado

---

## 📥 Instalação Completa

### **Passo 1: Instalar Native Host** ⭐ **OBRIGATÓRIO**

1. Acesse: **https://github.com/fluxmed/fluxsigner-support/releases/latest**
2. Baixe: `FluxSignerSetup.exe`
3. Execute o instalador
4. Aguarde a conclusão (instala JAR, registra no Windows, etc.)

### **Passo 2: Instalar Esta Extensão**

**Opção A: Chrome Web Store** *(Recomendado - em breve)*
- Busque "FluxSigner" na Chrome Web Store
- Clique "Adicionar ao Chrome"

**Opção B: Instalação Manual** *(Para desenvolvedores)*
1. Clone o repositório
2. Abra `chrome://extensions`
3. Ative "Modo desenvolvedor"
4. Clique "Carregar descompactada"
5. Selecione a pasta `App/`

---

## 🚀 Como Usar

### **1. Abrir a Extensão**
- Clique no ícone do FluxSigner na barra de ferramentas
- Ou use o atalho (se configurado)

### **2. Selecionar Certificado**
- A extensão lista automaticamente seus certificados ICP-Brasil
- Escolha o certificado desejado
- Você verá: Nome, CPF/CNPJ, Emissor, Validade

### **3. Assinar Documento**
- Selecione o arquivo PDF
- Clique em "Assinar PDF"
- O PDF será assinado com timestamp TSA automático
- Download inicia automaticamente

### **4. Verificar Assinatura** *(Opcional)*
- Selecione um PDF assinado
- A extensão mostra:
  - ✅ Validade da assinatura
  - ✅ Informações do certificado
  - ✅ Timestamp (se presente)
  - ✅ Integridade do documento

---

## 🔒 Segurança e Privacidade

### **Processamento Local**
- ✅ Nenhum dado é enviado para servidores externos
- ✅ Certificados permanecem no Windows Certificate Store
- ✅ PDFs nunca deixam seu computador
- ✅ Chaves privadas nunca são expostas

### **Conformidade ICP-Brasil**
- ✅ Padrão PAdES (PDF Advanced Electronic Signatures)
- ✅ Validação completa da cadeia de certificação
- ✅ Verificação de revogação (OCSP/CRL)
- ✅ Algoritmos aprovados (SHA-256, RSA 2048+)

### **Timestamp Confiável**
- ✅ TSA (Time Stamping Authority) automático
- ✅ Serviços credenciados ICP-Brasil (ITI, SERPRO, Receita Federal)
- ✅ Prova temporal irrefutável

---

## ❓ Solução de Problemas

### **"Native host not found"**

**Causa**: Native Host não está instalado ou não está registrado corretamente.

**Solução**:
1. Baixe e instale: https://github.com/fluxmed/fluxsigner-support/releases/latest
2. Execute `FluxSignerSetup.exe`
3. Reinicie o navegador
4. Tente novamente

### **"Nenhum certificado encontrado"**

**Causa**: Nenhum certificado ICP-Brasil instalado no Windows.

**Solução**:
1. Abra `certmgr.msc` (Gerenciador de Certificados)
2. Vá em "Pessoal" → "Certificados"
3. Instale seu certificado ICP-Brasil
4. Recarregue a extensão

### **"Erro ao assinar PDF"**

**Possíveis causas**:
- PDF corrompido ou protegido por senha
- Certificado expirado
- Token A3 desconectado (se usar A3)

**Solução**:
1. Verifique se o PDF é válido
2. Verifique validade do certificado
3. Reconecte o token (A3)
4. Tente novamente

### **Timestamp falhou**

**Causa**: Problema de conexão com servidores TSA.

**Solução**:
- A assinatura continua válida (sem timestamp)
- Verifique sua conexão com a internet
- Tente novamente

---

## 📚 Documentação Adicional

- **[Documentação Completa](https://github.com/fluxmed/fluxsigner-support)**
- **[API Reference](https://github.com/fluxmed/fluxsigner-support/blob/main/API_DOCUMENTATION.md)**
- **[Changelog](https://github.com/fluxmed/fluxsigner-support/blob/main/CHANGELOG.md)**
- **[Política de Privacidade](https://github.com/fluxmed/fluxsigner-support/blob/main/PRIVACY_POLICY.md)**

---

## 🆘 Suporte

### **Precisa de Ajuda?**

- **GitHub Issues**: [github.com/fluxmed/fluxsigner-support/issues](https://github.com/fluxmed/fluxsigner-support/issues)
- **Documentação**: [github.com/fluxmed/fluxsigner-support](https://github.com/fluxmed/fluxsigner-support)
- **Email**: contato@fluxsigner.com.br

### **Reportar Bug**

Se encontrou um bug, por favor inclua:
1. Versão da extensão
2. Sistema operacional e versão
3. Passos para reproduzir
4. Mensagem de erro (se houver)
5. Screenshots (se aplicável)

---

## 📄 Licença

Este projeto está sob licença proprietária. Consulte o arquivo LICENSE para detalhes.

---

## 🤝 Contribuindo

Contribuições são bem-vindas! Por favor:

1. Fork o projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

---

**Versão:** 2.1.0  
**Última atualização:** Outubro 2025  
**Status:** Produção ✅

---

<div align="center">

**🔐 FluxSigner - Assinatura Digital ICP-Brasil Simplificada**

[GitHub](https://github.com/fluxmed/fluxsigner-support) • 
[Releases](https://github.com/fluxmed/fluxsigner-support/releases) • 
[Issues](https://github.com/fluxmed/fluxsigner-support/issues)

</div>
